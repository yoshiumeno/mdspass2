#include <iostream>
#include <stdlib.h>
#include <fstream>
#include "myheader.h"

void bond_set();

void bookkeep()
{
  int ix, iy, iz, nrpx, nrpy, nrpz;
  double r2;
  if (book.algo == 3) { return; }
  nrpx = 0; nrpy = 0; nrpz = 0;
  //  if (cell.pbcx) { nrpx=book.frc*2.0/sqrt(cell.hmat[1][1]*cell.hmat[1][1]+cell.hmat[2][1]*cell.hmat[2][1]+cell.hmat[3][1]*cell.hmat[3][1])+1; }
  //  if (cell.pbcy) { nrpy=book.frc*2.0/sqrt(cell.hmat[1][2]*cell.hmat[1][2]+cell.hmat[2][2]*cell.hmat[2][2]+cell.hmat[3][2]*cell.hmat[3][2])+1; }
  //  if (cell.pbcz) { nrpz=book.frc*2.0/sqrt(cell.hmat[1][3]*cell.hmat[1][3]+cell.hmat[2][3]*cell.hmat[2][3]+cell.hmat[3][3]*cell.hmat[3][3])+1; }
  if (cell.pbcx) { nrpx=(int)(book.frc*2/cell.hmat[1][1]+1); }
  if (cell.pbcy) { nrpy=(int)(book.frc*2/cell.hmat[2][2]+1); }
  if (cell.pbcz) { nrpz=(int)(book.frc*2/cell.hmat[3][3]+1); }
  //std::cout<<"Bookkeep: Range= "<<nrpx<<" x "<<nrpy<<" x "<<nrpz<<std::endl;
  for (int i=1; i<=atom.natom; i++) {
    book.alistnum[i] = 0;
  for (int j=1; j<=atom.natom; j++) {
    if ((nrpx<=1)&&(nrpy<=1)&&(nrpz<=1)) {
      if (atom.Dist2Closest(i,j,ix,iy,iz)<book.frc2) {
	if (atom.Dist2Closest(i,j,ix,iy,iz)>1.0e-30) {
	  book.alistnum[i]++;
	  book.alist[i][book.alistnum[i]][0] = j;
	  book.alist[i][book.alistnum[i]][1] = ix;
	  book.alist[i][book.alistnum[i]][2] = iy;
	  book.alist[i][book.alistnum[i]][3] = iz;
	  //	  std::cout<<"hoge"<<std::endl;
	}
      }
    } else {
      for (int ixx=-nrpx; ixx<=nrpx; ixx++) {
      for (int iyy=-nrpy; iyy<=nrpy; iyy++) {
      for (int izz=-nrpz; izz<=nrpz; izz++) {
	if (atom.Dist2(i,j,ixx,iyy,izz)<book.frc2) {
	  if (atom.Dist2(i,j,ixx,iyy,izz)>1.0e-30) {
	    book.alistnum[i]++;
	    book.alist[i][book.alistnum[i]][0] = j;
	    book.alist[i][book.alistnum[i]][1] = ixx;
	    book.alist[i][book.alistnum[i]][2] = iyy;
	    book.alist[i][book.alistnum[i]][3] = izz;
	  }
	}
      }
      }
      }
    }
    if (book.alistnum[i]>=NBOOK) {
      std::cout<<"Bookkeep Error: NBOOK too small"<<std::endl;
    }
  }
  }
  bond_set();
}

/*    
int search_neighbor(i, j, &ix, &iy, &iz)
{
  double sdx, sdy, sdz;
  sdx = atom.rx[i] - atom.rx[j];
  sdy = atom.ry[i] - atom.ry[j];
  sdz = atom.rz[i] - atom.rz[j];
}
*/
