#include <iostream>
#include<string.h>
#include<stdlib.h>
#include<fstream>
#include "myheader.h"

void e_force_adp()
{
  double rr, rr2, drx, dry, drz, vp0, v0;
  int j, ix, iy, iz;
  //double rcut = 8.0e0; double rcut2 = rcut * rcut;
  int    self;
  int    h, k, l, typ1, typ2, uf, us, stresses, ipair;
  double value, grad, value_tail, grad_tail, grad_i, grad_j, p_sr_tail;
  double value_el, grad_el, ggrad_el;

}
