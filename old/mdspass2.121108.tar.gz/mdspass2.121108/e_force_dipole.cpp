#include <iostream>
#include<string.h>
#include<stdlib.h>
#include<fstream>
#include "myheader.h"

void dipole_alloc();
void dipole_param();
void buckingham(double r, double &e, double &f, double a, double sig, double c);
void bucksft(double r, double &e, double &f, double a, double sig, double c,
	     double rc, double vrc, double vprc);
void elstat_shift(double r, double dp_kappa, double &value_tail, double &grad_tail,
		  double &ggrad_tail);
void elstat_value(double r, double dp_kappa, double &ftail, double &gtail,
		  double &ggtail);
double shortrange_value(double r, double a, double b, double c);
void shortrange_term(double r, double b, double c, double &srval_tail,
		     double &srgrad_tail);
int atom_number(char* at);
int dptyp(char* at);
int pairtyp(char* ati, char* atj);
double dsquare(double d);
void resetmat(double a[3][3]);

void e_force_dipole()
{
  double rr, rr2, drx, dry, drz, vp0, v0;
  int j, ix, iy, iz;
  //double rcut = 8.0e0; double rcut2 = rcut * rcut;
  int    self;
  int    h, k, l, typ1, typ2, uf, us, stresses, ipair;
  double value, grad, value_tail, grad_tail, grad_i, grad_j, p_sr_tail;
  double value_el, grad_el, ggrad_el;

  if (dipole.initialize) {
    std::cout<<"Initialize of the DIPOLE potential.."<<std::endl;
    dipole_alloc();
    dipole_param();
    dipole.initialize = false;
    std::cout<<" done."<<std::endl;
  }
  double rcut = dipole.dp_cut; double rcut2 = rcut * rcut;

  // Reset dipoles and fields: LOOP ZERO
  for (int i=1; i<=atom.natom; i++) {
    dipole.E_totx[i] = 0; dipole.E_toty[i] = 0; dipole.E_totz[i] = 0;
    dipole.E_indx[i] = 0; dipole.E_indy[i] = 0; dipole.E_indz[i] = 0;
    dipole.p_indx[i] = 0; dipole.p_indy[i] = 0; dipole.p_indz[i] = 0;
    dipole.E_statx[i] = 0; dipole.E_staty[i] = 0; dipole.E_statz[i] = 0;
    dipole.p_srx[i]   = 0; dipole.p_sry[i]   = 0; dipole.p_srz[i]   = 0; }

  // FIRST LOOP
  for (int i=1; i<=atom.natom; i++) {
    atom.fx[i] = 0.0; atom.fy[i] = 0.0; atom.fz[i] = 0.0;  atom.epot[i] = 0.0;
    for (int j=0; j<3; j++) { for (int k=0; k<3; k++) {
	atom.satom[i][j][k] = 0.0; } }
  }// FIRST LOOP END

  // SECOND LOOP: calculate short-range and monopole forces,
  // calculate static field- and dipole-contributions
  for (int i=1; i<=atom.natom; i++) {
    typ1 = dptyp(atom.asp[i]);
    if (book.alistnum[i]>0) { for (int k=1; k<=book.alistnum[i]; k++) {
	j  = book.alist[i][k][0];
	if (j<i) continue;
	ix = book.alist[i][k][1]; iy = book.alist[i][k][2]; iz = book.alist[i][k][3];
	rr2 = atom.Dist2(i,j,ix,iy,iz)/ang/ang; rr = sqrt(rr2);
	typ2 = dptyp(atom.asp[j]);
	ipair = pairtyp(atom.asp[i],atom.asp[j]); // type of pair interaction
	elstat_shift(rr, dipole.dp_kappa, value_el, grad_el, ggrad_el); //tail-functions
	drx = atom.Dx(i,j,ix,iy,iz); dry = atom.Dy(i,j,ix,iy,iz); drz = atom.Dz(i,j,ix,iy,iz);
	drx /= ang; dry /= ang; drz /= ang;
	if ((rr < rcut)&&(ipair!=0)) { // calculate short-range forces
	  self = 0; if (i==j) { self = 1; }
	  buckingham(rr, value, grad, dipole.buck_a[ipair], dipole.buck_s[ipair]
	  	     ,dipole.buck_c[ipair]); //Buckingham type
	  // For consistency with POTFIT, buckingham should be replaced with bucksft.
	  // For bucksft, buck_vprc and buck_vrc must be given in initialization.
	  // (However, bucksft seems weird...)
	  //bucksft(rr, value, grad, dipole.buck_a[ipair], dipole.buck_s[ipair]
	  //	  ,dipole.buck_c[ipair]
	  //	  ,dipole.dp_cut,dipole.buck_vrc[ipair],dipole.buck_vprc[ipair]);
	  if (self) { value *= 0.5; grad *= 0.5; }
	  grad /= rr;
	  atom.epot[i] += value/2.0; atom.epot[j] += value/2.0; // -3 contribution. OK!!
	  atom.fx[i] += drx*grad; atom.fy[i] += dry*grad; atom.fz[i] += drz*grad;
	  atom.fx[j] -= drx*grad; atom.fy[j] -= dry*grad; atom.fz[j] -= drz*grad;
	  // stress
	  atom.satom[i][0][0] += drx*drx*grad/2.0;
	  atom.satom[i][0][1] += dry*drx*grad/2.0;
	  atom.satom[i][0][2] += drz*drx*grad/2.0;
	  atom.satom[i][1][1] += dry*dry*grad/2.0;
	  atom.satom[i][1][2] += drz*dry*grad/2.0;
	  atom.satom[i][2][2] += drz*drz*grad/2.0;
	  atom.satom[j][0][0] += drx*drx*grad/2.0;
	  atom.satom[j][0][1] += dry*drx*grad/2.0;
	  atom.satom[j][0][2] += drz*drx*grad/2.0;
	  atom.satom[j][1][1] += dry*dry*grad/2.0;
	  atom.satom[j][1][2] += drz*dry*grad/2.0;
	  atom.satom[j][2][2] += drz*drz*grad/2.0;
	}
	if (rr < dipole.dp_cut) { // calculate monopole forces
	  self = 0; if (i==j) { self = 1; }
	  value_tail = value_el;
	  grad_tail  = grad_el;
	  grad_i = dipole.charge[typ2] * grad_tail;
	  if (typ1 == typ2) { grad_j = grad_i;
	  } else { grad_j = dipole.charge[typ1] * grad_tail; }
	  value = dipole.charge[typ1] * dipole.charge[typ2] * value_tail;
	  grad  = dipole.charge[typ1] * grad_i;
	  if (self) { grad_i *= 0.5; grad_j *= 0.5; value *= 0.5; grad *= 0.5; }
	  atom.epot[i] += value/2.0; atom.epot[j] += value/2.0; // -18 contribution DUBIOUS!!
	  atom.fx[i] += drx*grad; atom.fy[i] += dry*grad; atom.fz[i] += drz*grad;
	  atom.fx[j] -= drx*grad; atom.fy[j] -= dry*grad; atom.fz[j] -= drz*grad;
	  // stress
	  atom.satom[i][0][0] += drx*drx*grad/2.0;
	  atom.satom[i][0][1] += dry*drx*grad/2.0;
	  atom.satom[i][0][2] += drz*drx*grad/2.0;
	  atom.satom[i][1][1] += dry*dry*grad/2.0;
	  atom.satom[i][1][2] += drz*dry*grad/2.0;
	  atom.satom[i][2][2] += drz*drz*grad/2.0;
	  atom.satom[j][0][0] += drx*drx*grad/2.0;
	  atom.satom[j][0][1] += dry*drx*grad/2.0;
	  atom.satom[j][0][2] += drz*drx*grad/2.0;
	  atom.satom[j][1][1] += dry*dry*grad/2.0;
	  atom.satom[j][1][2] += drz*dry*grad/2.0;
	  atom.satom[j][2][2] += drz*drz*grad/2.0;
	  // calculate static field-contributions
	  dipole.E_statx[i] += drx*grad_i; dipole.E_statx[j] -= drx*grad_j;
	  dipole.E_staty[i] += dry*grad_i; dipole.E_staty[j] -= dry*grad_j;
	  dipole.E_statz[i] += drz*grad_i; dipole.E_statz[j] -= drz*grad_j;
	  // calculate short-range dipoles
	  if (ipair!=0) {
	  p_sr_tail = grad_tail*rr
	    *shortrange_value(rr, dipole.dp_alpha[typ1], dipole.dp_b[ipair],
			      dipole.dp_c[ipair]);
	  dipole.p_srx[i] += dipole.charge[typ2]*drx/rr*p_sr_tail;
	  dipole.p_sry[i] += dipole.charge[typ2]*dry/rr*p_sr_tail;
	  dipole.p_srz[i] += dipole.charge[typ2]*drz/rr*p_sr_tail;
	  if (!self) {
	    p_sr_tail = grad_tail*rr
	      *shortrange_value(rr, dipole.dp_alpha[typ2], dipole.dp_b[ipair],
				dipole.dp_c[ipair]);
	    dipole.p_srx[j] -= dipole.charge[typ1]*drx/rr*p_sr_tail;
	    dipole.p_sry[j] -= dipole.charge[typ1]*dry/rr*p_sr_tail;
	    dipole.p_srz[j] -= dipole.charge[typ1]*drz/rr*p_sr_tail; }
	  }
	}
      } }
  } // SECOND LOOP END

  // THIRD LOOP: calculate whole dipole moment for every atom
  double rp, dp_sum;
  int dp_converged = 0, dp_it = 0;
  double max_diff = 10;
  //  goto OUT;
  while (dp_converged == 0) {
    dp_sum = 0;
    for (int i=1; i<=atom.natom; i++) {
      typ1 = dptyp(atom.asp[i]);
      if (dipole.dp_alpha[typ1]!=0) {
      if (dp_it) {
	dipole.E_totx[i] = (1-dipole.dp_mix)*dipole.E_indx[i]
	  + dipole.dp_mix*dipole.E_oldx[i] + dipole.E_statx[i];
	dipole.E_toty[i] = (1-dipole.dp_mix)*dipole.E_indy[i]
	  + dipole.dp_mix*dipole.E_oldy[i] + dipole.E_staty[i];
	dipole.E_totz[i] = (1-dipole.dp_mix)*dipole.E_indz[i]
	  + dipole.dp_mix*dipole.E_oldz[i] + dipole.E_statz[i];
      } else {
	dipole.E_totx[i] = dipole.E_indx[i] + dipole.E_statx[i];
	dipole.E_toty[i] = dipole.E_indy[i] + dipole.E_staty[i];
	dipole.E_totz[i] = dipole.E_indz[i] + dipole.E_statz[i];
      } // if dp_it
      dipole.p_indx[i] = dipole.dp_alpha[typ1] * dipole.E_totx[i] + dipole.p_srx[i];
      dipole.p_indy[i] = dipole.dp_alpha[typ1] * dipole.E_toty[i] + dipole.p_sry[i];
      dipole.p_indz[i] = dipole.dp_alpha[typ1] * dipole.E_totz[i] + dipole.p_srz[i];
      dipole.E_oldx[i] = dipole.E_indx[i]; dipole.E_indx[i] = 0.;
      dipole.E_oldy[i] = dipole.E_indy[i]; dipole.E_indy[i] = 0.;
      dipole.E_oldz[i] = dipole.E_indz[i]; dipole.E_indz[i] = 0.;
      }
    } // loop of i (atoms)

    for (int i=1; i<=atom.natom; i++) {
      typ1 = dptyp(atom.asp[i]);
      if (book.alistnum[i]>0) { for (int k=1; k<=book.alistnum[i]; k++) {
	  j  = book.alist[i][k][0];
	  if (j<i) continue;
	  ix = book.alist[i][k][1]; iy = book.alist[i][k][2]; iz = book.alist[i][k][3];
	  rr2 = atom.Dist2(i,j,ix,iy,iz)/ang/ang; rr = sqrt(rr2);
	  typ2 = dptyp(atom.asp[j]);
	  ipair = pairtyp(atom.asp[i],atom.asp[j]); // type of pair interaction
	  elstat_shift(rr, dipole.dp_kappa, value_el, grad_el, ggrad_el); //tail-functions
	  if (rr < rcut) { // calculate short-range forces
	    if ((dipole.dp_alpha[typ1]!=0)&&(dipole.dp_alpha[typ2]!=0)) {
	    self = 0; if (i==j) { self = 1; }
	    drx = atom.Dx(i,j,ix,iy,iz); dry = atom.Dy(i,j,ix,iy,iz); drz = atom.Dz(i,j,ix,iy,iz);
	    drx /= ang; dry /= ang; drz /= ang;
	    drx /=rr; dry /=rr; drz /=rr;
	    rp = dipole.p_indx[j]*drx + dipole.p_indy[j]*dry + dipole.p_indz[j]*drz;
	    dipole.E_indx[i] += grad_el*(3*rp*drx-dipole.p_indx[j]);
	    dipole.E_indy[i] += grad_el*(3*rp*dry-dipole.p_indy[j]);
	    dipole.E_indz[i] += grad_el*(3*rp*drz-dipole.p_indz[j]);
	    if (!self) {
	      rp = dipole.p_indx[i]*drx + dipole.p_indy[i]*dry + dipole.p_indz[i]*drz;
	      dipole.E_indx[j] += grad_el*(3*rp*drx-dipole.p_indx[i]);
	      dipole.E_indy[j] += grad_el*(3*rp*dry-dipole.p_indy[i]);
	      dipole.E_indz[j] += grad_el*(3*rp*drz-dipole.p_indz[i]);
	    }
	    }}
	} } // j
    } // loop of i (atoms)
    for (int i=1; i<=atom.natom; i++) {
      typ1 = dptyp(atom.asp[i]);
      dp_sum += dsquare(dipole.dp_alpha[typ1]*(dipole.E_oldx[i]-dipole.E_indx[i]));
      dp_sum += dsquare(dipole.dp_alpha[typ1]*(dipole.E_oldy[i]-dipole.E_indy[i]));
      dp_sum += dsquare(dipole.dp_alpha[typ1]*(dipole.E_oldz[i]-dipole.E_indz[i]));
    } // loop of i (atoms)

    dp_sum /= 3*(double)atom.natom;
    dp_sum = sqrt(dp_sum);

    if (dp_it) {
      if ((dp_sum > max_diff) || (dp_it > 50)) {
	dp_converged = 1;
	//printf("dp (failure) dp_sum=%e  dp_it=%d\n",dp_sum,dp_it);
	for (int i=1; i<=atom.natom; i++) {
	  typ1 = dptyp(atom.asp[i]);
	  if (dipole.dp_alpha[typ1]!=0) {
	    dipole.p_indx[i] = dipole.dp_alpha[typ1]*dipole.E_statx[i]+dipole.p_srx[i];
	    dipole.p_indy[i] = dipole.dp_alpha[typ1]*dipole.E_staty[i]+dipole.p_sry[i];
	    dipole.p_indz[i] = dipole.dp_alpha[typ1]*dipole.E_statz[i]+dipole.p_srz[i];
	    dipole.E_indx[i] = dipole.E_statx[i];
	    dipole.E_indy[i] = dipole.E_staty[i];
	    dipole.E_indz[i] = dipole.E_statz[i]; }
	}
      }
    } // if dp_it
    if (dp_sum < dipole.dp_tol) {
      dp_converged = 1;
      //printf("dp (success) dp_it=%d\n",dp_it);
    }
    dp_it++;
  } // while dp_converged (THIRD LOOP END)

  // FOURTH LOOP: calculate monopole-dipole and dipole-dipole forces
  double  rp_i, rp_j, pp_ij, tmp_1, tmp_2, tmpx, tmpy, tmpz;
  double  grad_1, grad_2, srval, srgrad, srval_tail, srgrad_tail, value_sum,
    grad_sum;
  for (int i=1; i<=atom.natom; i++) {
    typ1 = dptyp(atom.asp[i]);
    if (book.alistnum[i]>0) { for (int k=1; k<=book.alistnum[i]; k++) {
	j  = book.alist[i][k][0];
	if (j<i) continue;
	ix = book.alist[i][k][1]; iy = book.alist[i][k][2]; iz = book.alist[i][k][3];
	rr2 = atom.Dist2(i,j,ix,iy,iz)/ang/ang; rr = sqrt(rr2);
	typ2 = dptyp(atom.asp[j]);
	ipair = pairtyp(atom.asp[i],atom.asp[j]); // type of pair interaction
	elstat_shift(rr, dipole.dp_kappa, value_el, grad_el, ggrad_el); //tail-functions
	if ((rr < dipole.dp_cut)&&((dipole.dp_alpha[typ1]!=0)||(dipole.dp_alpha[typ2]!=0))) {
	  self = 0; if (i==j) { self = 1; }
	  value_tail = -grad_el;
	  grad_tail  = -ggrad_el;
	  if (ipair!=0) {
	    shortrange_term(rr, dipole.dp_b[ipair], dipole.dp_c[ipair], srval_tail, srgrad_tail);
	    srval = value_tail * srval_tail;
	    srgrad = value_tail * srgrad_tail + grad_tail * srval_tail;
	  }
	  if (self) { value_tail *= 0.5; grad_tail *= 0.5; }
	  // monopole-dipole contributions //if (charge[typ1] && dp_alpha[typ2]) 
	  if (ipair!=0) {
	    value_sum = value_tail + srval;
	    grad_sum  = grad_tail + srgrad;
	  } else {
	    value_sum = value_tail;
	    grad_sum  = grad_tail;
	  }
	  drx = atom.Dx(i,j,ix,iy,iz); dry = atom.Dy(i,j,ix,iy,iz); drz = atom.Dz(i,j,ix,iy,iz);
	  drx /= ang; dry /= ang; drz /= ang;
	  drx /=rr; dry /=rr; drz /=rr;
	  rp_j = dipole.p_indx[j]*drx + dipole.p_indy[j]*dry + dipole.p_indz[j]*drz;
	  value  = dipole.charge[typ1] * rp_j * value_sum * rr;
	  grad_1 = dipole.charge[typ1] * rp_j * grad_sum * rr2;
	  grad_2 = dipole.charge[typ1] * value_sum;
	  atom.epot[i] -= value/2.0; atom.epot[j] -= value/2.0;  // DUBIOUS!!!
	  tmpx = drx * grad_1 + dipole.p_indx[j] * grad_2;
	  tmpy = dry * grad_1 + dipole.p_indy[j] * grad_2;
	  tmpz = drz * grad_1 + dipole.p_indz[j] * grad_2;
	  atom.fx[i] -= tmpx; atom.fy[i] -= tmpy; atom.fz[i] -= tmpz;
	  atom.fx[j] += tmpx; atom.fy[j] += tmpy; atom.fz[j] += tmpz;
	  // stress
	  atom.satom[i][0][0] -= tmpx*drx/2.0;
	  atom.satom[i][0][1] -= tmpx*dry/2.0;
	  atom.satom[i][0][2] -= tmpx*drz/2.0;
	  atom.satom[i][1][1] -= tmpy*dry/2.0;
	  atom.satom[i][1][2] -= tmpy*drz/2.0;
	  atom.satom[i][2][2] -= tmpz*drz/2.0;
	  atom.satom[j][0][0] -= tmpx*drx/2.0;
	  atom.satom[j][0][1] -= tmpx*dry/2.0;
	  atom.satom[j][0][2] -= tmpx*drz/2.0;
	  atom.satom[j][1][1] -= tmpy*dry/2.0;
	  atom.satom[j][1][2] -= tmpy*drz/2.0;
	  atom.satom[j][2][2] -= tmpz*drz/2.0;
	  // dipole-monopole contributions //if (dp_alpha[typ2] && charge[typ2])
	  if (ipair!=0) {
	    value_sum = value_tail + srval;
	    grad_sum  = grad_tail + srgrad;
	  } else {
	    value_sum = value_tail;
	    grad_sum  = grad_tail;
	  }
	  rp_i = dipole.p_indx[i]*drx + dipole.p_indy[i]*dry + dipole.p_indz[i]*drz;
	  value  = dipole.charge[typ2] * rp_i * value_sum * rr;
	  grad_1 = dipole.charge[typ2] * rp_i * grad_sum * rr2;
	  grad_2 = dipole.charge[typ2] * value_sum;
	  atom.epot[i] += value/2.0;  atom.epot[j] += value/2.0;
	  tmpx = drx * grad_1 + dipole.p_indx[i] * grad_2;
	  tmpy = dry * grad_1 + dipole.p_indy[i] * grad_2;
	  tmpz = drz * grad_1 + dipole.p_indz[i] * grad_2;
	  atom.fx[i] += tmpx; atom.fy[i] += tmpy; atom.fz[i] += tmpz;
	  atom.fx[j] -= tmpx; atom.fy[j] -= tmpy; atom.fz[j] -= tmpz;
	  // stress
	  atom.satom[i][0][0] += tmpx*drx/2.0;
	  atom.satom[i][0][1] += tmpx*dry/2.0;
	  atom.satom[i][0][2] += tmpx*drz/2.0;
	  atom.satom[i][1][1] += tmpy*dry/2.0;
	  atom.satom[i][1][2] += tmpy*drz/2.0;
	  atom.satom[i][2][2] += tmpz*drz/2.0;
	  atom.satom[j][0][0] += tmpx*drx/2.0;
	  atom.satom[j][0][1] += tmpx*dry/2.0;
	  atom.satom[j][0][2] += tmpx*drz/2.0;
	  atom.satom[j][1][1] += tmpy*dry/2.0;
	  atom.satom[j][1][2] += tmpy*drz/2.0;
	  atom.satom[j][2][2] += tmpz*drz/2.0;
	  // dipole-dipole contributions //if (dp_alpha[typ1] && dp_alpha[typ2])
	  if ((dipole.dp_alpha[typ1]!=0)&&(dipole.dp_alpha[typ2]!=0)) {
	  pp_ij = dipole.p_indx[i]*dipole.p_indx[j]
	    + dipole.p_indy[i]*dipole.p_indy[j] + dipole.p_indz[i]*dipole.p_indz[j];
	  tmp_1 = 3 * rp_i * rp_j;
	  tmp_2 = 3 * value_tail / rr2;
	  value = -(tmp_1 - pp_ij) * value_tail;
	  grad_1 = (tmp_1 - pp_ij) * grad_tail;
	  grad_2 = 2 * rp_i * rp_j;
	  atom.epot[i] += value/2.0; atom.epot[j] += value/2.0;
	  tmpx = grad_1 * rr * drx - tmp_2 * 
	    (grad_2 * rr * drx - rp_i * rr * dipole.p_indx[j] 
	     - rp_j * rr * dipole.p_indx[i]);
	  tmpy = grad_1 * rr * dry - tmp_2 * 
	    (grad_2 * rr * dry - rp_i * rr * dipole.p_indy[j] 
	     - rp_j * rr * dipole.p_indy[i]);
	  tmpz = grad_1 * rr * drz - tmp_2 * 
	    (grad_2 * rr * drz - rp_i * rr * dipole.p_indz[j] 
	     - rp_j * rr * dipole.p_indz[i]);
	  atom.fx[i] -= tmpx; atom.fx[j] += tmpx;
	  atom.fy[i] -= tmpy; atom.fy[j] += tmpy;
	  atom.fz[i] -= tmpz; atom.fz[j] += tmpz;
	  // stress
	  atom.satom[i][0][0] -= tmpx*drx/2.0;
	  atom.satom[i][0][1] -= tmpx*dry/2.0;
	  atom.satom[i][0][2] -= tmpx*drz/2.0;
	  atom.satom[i][1][1] -= tmpy*dry/2.0;
	  atom.satom[i][1][2] -= tmpy*drz/2.0;
	  atom.satom[i][2][2] -= tmpz*drz/2.0;
	  atom.satom[j][0][0] -= tmpx*drx/2.0;
	  atom.satom[j][0][1] -= tmpx*dry/2.0;
	  atom.satom[j][0][2] -= tmpx*drz/2.0;
	  atom.satom[j][1][1] -= tmpy*dry/2.0;
	  atom.satom[j][1][2] -= tmpy*drz/2.0;
	  atom.satom[j][2][2] -= tmpz*drz/2.0;
	  }
	}
      } }
  } // FOURTH LOOP END

  // FIFTH LOOP: self energy contributions and sum-up force contributions
  double qq, pp;
  for (int i=1; i<=atom.natom; i++) {
    typ1 = dptyp(atom.asp[i]);
    // self energy contributions
    qq = dipole.charge[typ1]*dipole.charge[typ1];
    value = dipole.dp_eps * dipole.dp_kappa * qq / sqrt(M_PI);
    atom.epot[i] -= value;
    if (dipole.dp_alpha[typ1] != 0.0) {
      pp = dipole.p_indx[i]*dipole.p_indx[i]
	+ dipole.p_indy[i]*dipole.p_indy[i] + dipole.p_indz[i]*dipole.p_indz[i];
      //printf("%d %e %e\n",i,pp,dipole.p_indx[i]);
      value = pp / (2 * dipole.dp_alpha[typ1]);
      atom.epot[i] += value;
    }
  } // FIFTH LOOP END

  //atom.epotsum=0.0;
  //for (int i=1; i<=atom.natom; i++) {
  //  atom.epotsum += atom.epot[i]*ev;
  //}
  //printf("%e   %e %e %e\n",atom.epotsum,atom.fx[1],atom.fy[1],atom.fz[1]);

 OUT:
  atom.epotsum=0.0;
  for (int i=1; i<=atom.natom; i++) {
    atom.epot[i] *= ev;
    atom.epotsum += atom.epot[i];
    atom.fx[i] *= ev/ang; atom.fy[i] *= ev/ang; atom.fz[i] *= ev/ang;
    //printf("%10d %20.12e %20.12e %20.12e\n",i-1,atom.fx[i]/ev*ang,atom.fy[i]/ev*ang,atom.fz[i]/ev*ang);
  }
    
  //Atomic stress
  for (int i=1; i<=atom.natom; i++) {
    atom.satom[i][1][0] = atom.satom[i][0][1];
    atom.satom[i][2][0] = atom.satom[i][0][2];
    atom.satom[i][2][1] = atom.satom[i][1][2]; }
  resetmat(cell.dmat);
  for (int i=1; i<=atom.natom; i++) {
    for (int j=0; j<3; j++) {
      for (int k=0; k<3; k++) {
	atom.satom[i][j][k] *= ev;
	cell.dmat[j][k] -= atom.satom[i][j][k]; } } }
  cell.virx = cell.dmat[0][0];
  cell.viry = cell.dmat[1][1];
  cell.virz = cell.dmat[2][2];
  for (int i=1; i<=atom.natom; i++) {
    for (int j=0; j<3; j++) {
      for (int k=0; k<3; k++) {
	atom.satom[i][j][k] *= (double)atom.natom / cell.volume; } } }

} // end of e_force_dipole

void dipole_alloc()
{
  if (dipole.dp_alpha) { delete dipole.dp_alpha; }
  if (dipole.dp_b)     { delete dipole.dp_b;     }
  if (dipole.dp_c)     { delete dipole.dp_c;     }
  if (dipole.E_statx)  { delete dipole.E_statx;  }
  if (dipole.E_staty)  { delete dipole.E_staty;  }
  if (dipole.E_statz)  { delete dipole.E_statz;  }
  if (dipole.E_indx)   { delete dipole.E_indx;   }
  if (dipole.E_indy)   { delete dipole.E_indy;   }
  if (dipole.E_indz)   { delete dipole.E_indz;   }
  if (dipole.E_oldx)   { delete dipole.E_oldx;   }
  if (dipole.E_oldy)   { delete dipole.E_oldy;   }
  if (dipole.E_oldz)   { delete dipole.E_oldz;   }
  if (dipole.E_totx)   { delete dipole.E_totx;   }
  if (dipole.E_toty)   { delete dipole.E_toty;   }
  if (dipole.E_totz)   { delete dipole.E_totz;   }
  if (dipole.p_srx)    { delete dipole.p_srx;    }
  if (dipole.p_sry)    { delete dipole.p_sry;    }
  if (dipole.p_srz)    { delete dipole.p_srz;    }
  if (dipole.p_indx)   { delete dipole.p_indx;   }
  if (dipole.p_indy)   { delete dipole.p_indy;   }
  if (dipole.p_indz)   { delete dipole.p_indz;   }
  if (dipole.charge)   { delete dipole.charge;   }
  if (dipole.buck_a)   { delete dipole.buck_a;   }
  if (dipole.buck_s)   { delete dipole.buck_s;   }
  if (dipole.buck_c)   { delete dipole.buck_c;   }
  dipole.dp_alpha = new double[dipole.ntype+1];
  dipole.dp_b     = new double[dipole.nptype+1];
  dipole.dp_c     = new double[dipole.nptype+1];
  dipole.E_statx  = new double[atom.natom+1];
  dipole.E_staty  = new double[atom.natom+1];
  dipole.E_statz  = new double[atom.natom+1];
  dipole.E_indx   = new double[atom.natom+1];
  dipole.E_indy   = new double[atom.natom+1];
  dipole.E_indz   = new double[atom.natom+1];
  dipole.E_oldx   = new double[atom.natom+1];
  dipole.E_oldy   = new double[atom.natom+1];
  dipole.E_oldz   = new double[atom.natom+1];
  dipole.E_totx   = new double[atom.natom+1];
  dipole.E_toty   = new double[atom.natom+1];
  dipole.E_totz   = new double[atom.natom+1];
  dipole.p_srx    = new double[atom.natom+1];
  dipole.p_sry    = new double[atom.natom+1];
  dipole.p_srz    = new double[atom.natom+1];
  dipole.p_indx   = new double[atom.natom+1];
  dipole.p_indy   = new double[atom.natom+1];
  dipole.p_indz   = new double[atom.natom+1];
  dipole.charge   = new double[dipole.ntype+1];
  dipole.buck_a   = new double[dipole.nptype+1];
  dipole.buck_s   = new double[dipole.nptype+1];
  dipole.buck_c   = new double[dipole.nptype+1];
  dipole.buck_vrc = new double[dipole.nptype+1];
  dipole.buck_vprc= new double[dipole.nptype+1];
}

int dptyp(char* at)
{
  int i = atom_number(at);
  if (i == 40) { return 1;
  } else if (i ==  8) { return 2;
  } else if (i == 39) { return 3;
  } else { return 0; }
}
int pairtyp(char* ati, char* atj)
{
  int i = dptyp(ati);
  int j = dptyp(atj);
  if (((i==1)&&(j==2))||((i==2)&&(j==1))) { return 1;
  } else if ((i==2)&&(j==2)) { return 2;
  } else if (((i==2)&&(j==3))||((i==3)&&(j==2))) { return 3;
  } else { return 0; }
}
void dipole_param()
{ //Zr=1, O=2, Y=3,  Zr-O=1, O-O=2, Y-O=3
  //dipole.dp_mix = 0.5;
  dipole.dp_kappa = 0.1;
  dipole.charge[1] = 2.116022;
  dipole.charge[2] =-1.055614;
  dipole.charge[3] = 1.511515;
  dipole.dp_alpha[1] = 0.;
  //dipole.dp_alpha[2] = 0.010019/dipole.dp_eps;
  dipole.dp_alpha[2] = 0.010019; // <===
  dipole.dp_alpha[3] = 0.;
  dipole.dp_b[1] = 13.439888; // per angstrom
  dipole.dp_b[2] = 59.408009;
  dipole.dp_b[3] = 68.516735;
  //dipole.dp_c[1] =  -0.170177*dipole.dp_eps;
  //dipole.dp_c[2] = -28.550774*dipole.dp_eps;
  //dipole.dp_c[3] =  -0.10000*dipole.dp_eps;
  //dipole.dp_c[3] =  -0.00000*dipole.dp_eps;
  dipole.dp_c[1] =  -0.170177;
  dipole.dp_c[2] = -28.550774;
  dipole.dp_c[3] =   0.00000;
  dipole.buck_a[1] = 7299.50008961;
  dipole.buck_a[2] = 8175.01587504;
  dipole.buck_a[3] = 6968.55253502;
  dipole.buck_s[1] = 0.22914290;
  dipole.buck_s[2] = 0.28736600;
  dipole.buck_s[3] = 0.23183401;
  dipole.buck_c[1] =  87383.66707018;
  dipole.buck_c[2] = 850244.09929026;
  dipole.buck_c[3] =  4700.69794845;

  dipole.dp_cut = 8.0;
  double value = 0.0, grad = 0.0;
  for (int i=1; i<=3; i++) {
    buckingham(dipole.dp_cut, value, grad, dipole.buck_a[i], dipole.buck_s[i],
  	       dipole.buck_c[i]);
    dipole.buck_vrc[i]  = value;
    dipole.buck_vprc[i] = grad;
    //printf("Buckingham shift %d %e %e\n",i,dipole.buck_vrc[i],dipole.buck_vprc[i]);
  }
}

void buckingham(double r, double &e, double &f, double a, double sig, double c)
{
  //  double rang = r;
  double x = sig/r; double x2 = x * x; double x3 = x2 * x;
  double x6 = x3 * x3; double x5 = x3 * x2;
  double exprs = exp(-r/sig);
  e = a * exprs - c * x6;
  f = -1.0/sig * a * exprs + c * 6.0 * x6 / r;
}
void bucksft(double r, double &e, double &f, double a, double sig, double c,
	     double rc, double vrc, double vprc)
{
  //  double rang = r;
  double x = sig/r; double x2 = x * x; double x3 = x2 * x;
  double x6 = x3 * x3; double x5 = x3 * x2;
  double exprs = exp(-r/sig);
  e = a * exprs - c * x6;
  f = -1.0/sig * a * exprs + c * 6.0 * x6 / r;
  e += -vrc - r*(r-rc)*vprc;
  f += (rc-2*r)*vprc;
}

double shortrange_value(double r, double a, double b, double c)
{
  static double x[5];

  x[0] = b * r;
  x[1] = x[0] * x[0];
  x[2] = x[1] * x[0];
  x[3] = x[1] * x[1];
  x[4] = 1 + x[0] + x[1] / 2 + x[2] / 6 + x[3] / 24;

  return a * c * x[4] * exp(-x[0]) / dipole.dp_eps;
}
void shortrange_term(double r, double b, double c, double &srval_tail,
  double &srgrad_tail)
{
  static double x[6];

  x[0] = b * r;
  x[1] = x[0] * x[0];
  x[2] = x[1] * x[0];
  x[3] = x[1] * x[1];
  x[4] = 1 + x[0] + x[1] / 2 + x[2] / 6 + x[3] / 24;
  x[5] = exp(-x[0]);

  srval_tail = c * x[4] * x[5] / dipole.dp_eps;
  srgrad_tail = -c * b * x[3] * x[5] / (24 * dipole.dp_eps * r);
}

void elstat_shift(double r, double dp_kappa, double &value_tail, double &grad_tail,
  double &ggrad_tail)
{
  static double ftail, gtail, ggtail, ftail_cut, gtail_cut, ggtail_cut;
  static double x[3];

  x[0] = r * r;
  x[1] = dipole.dp_cut * dipole.dp_cut;
  x[2] = x[0] - x[1];

  elstat_value(r, dp_kappa, ftail, gtail, ggtail);
  elstat_value(dipole.dp_cut, dp_kappa, ftail_cut, gtail_cut, ggtail_cut);

  value_tail = ftail - ftail_cut - x[2] * gtail_cut / 2;
  grad_tail = gtail - gtail_cut;
  ggrad_tail = 0.;

  value_tail -= x[2] * x[2] * ggtail_cut / 8;
  grad_tail -= x[2] * ggtail_cut / 2;
  ggrad_tail = ggtail - ggtail_cut;
}

void elstat_value(double r, double dp_kappa, double &ftail, double &gtail, double &ggtail)
{
  static double x[4];

  x[0] = r * r;
  x[1] = dp_kappa * dp_kappa;
  x[2] = 2 * dipole.dp_eps * dp_kappa / sqrt(M_PI);
  x[3] = exp(-x[0] * x[1]);

  ftail = dipole.dp_eps * erfc(dp_kappa * r) / r;
  gtail = -(ftail + x[2] * x[3]) / x[0];
  ggtail = (2 * x[1] * x[2] * x[3] - gtail * 3) / x[0];
}
double dsquare(double d)
{
  return d * d;
}
