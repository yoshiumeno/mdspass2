void inverse(double h[3][3], double hi[3][3])
{
  double deth
    = h[0][0]*h[1][1]*h[2][2] + h[0][1]*h[1][2]*h[2][0] 
    + h[0][2]*h[1][0]*h[2][1] - h[0][0]*h[1][2]*h[2][1] 
    - h[0][1]*h[1][0]*h[2][2] - h[0][2]*h[1][1]*h[2][0];
    
  hi[0][0]=(h[1][1]*h[2][2]-h[1][2]*h[2][1])/deth;
  hi[0][1]=(h[0][2]*h[2][1]-h[0][1]*h[2][2])/deth;
  hi[0][2]=(h[0][1]*h[1][2]-h[0][2]*h[1][1])/deth;
  hi[1][0]=(h[1][2]*h[2][0]-h[1][0]*h[2][2])/deth;
  hi[1][1]=(h[0][0]*h[2][2]-h[0][2]*h[2][0])/deth;
  hi[1][2]=(h[0][2]*h[1][0]-h[0][0]*h[1][2])/deth;
  hi[2][0]=(h[1][0]*h[2][1]-h[1][1]*h[2][0])/deth;
  hi[2][1]=(h[0][1]*h[2][0]-h[0][0]*h[2][1])/deth;
  hi[2][2]=(h[0][0]*h[1][1]-h[0][1]*h[1][0])/deth;
}

void resetmat(double a[3][3])
{
  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      a[i][j]=0; } }
}

void transpose(double a[3][3])
{
  double x;
  for (int i=0; i<3; i++) {
    for (int j=i+1; j<3; j++) {
      x=a[i][j]; a[i][j]=a[j][i]; a[j][i]=x; } }
}

//c = product(a,b)
void matmul(double a[3][3], double b[3][3], double c[3][3])
{
  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      c[i][j]=0.0;
      for (int k=0; k<3; k++) {
	c[i][j] += a[i][k]*b[k][j];
      } } }
}
