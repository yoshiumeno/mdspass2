#include <string.h>
#include <iostream>
#include <GL/glui.h>
#include <fstream>
#include <math.h>
#include <unistd.h>
//#ifdef __linux__
//#include <unistd.h>
//#else
//#include <direct.h>
//#endif

#define OPEN_FILE_ID 100
#define OPEN_FILE_QCELEMENT_ID 103
#define FILE_CLOSE_ID 101
#define QCELEMENT_CLOSE_ID 104
#define RESET_ID 102
#define WRITECONFIG_ID 1061
#define CREATECONFIG_ID 1062
#define CREATECONFIG_CLOSE_ID 1063
#define CREATECONFIG_DO_ID 1064
#define CNTWALL_DO_ID 1065
#define CNTWALL_READ_ID 1066
#define CNTWALL_WRITE_ID 1067
#define CNTWALL_CLOSE_ID 1068
#define WRITEQCELEMENT_ID 116
#define INST_ID 105
//#define SETDEXDT_ID 107
//#define SETDEXDT_CLOSE_ID 108
#define MDSWITCH_ID 109
#define EDIT_ELEM_ID 110
#define EDIT_ELEM_CLOSE_ID 111
#define EDIT_ELEM_TAKE_ID 112
#define EDIT_ELEM_XZ_ID 113
#define EDIT_ELEM_XZ_CLOSE_ID 114
#define EDIT_ELEM_XZ_TAKE_ID 115
#define SETPARAM_ID 200
#define SETPARAM_CLOSE_ID 201
#define SETPARAM_READ_ID 204
#define CELLSIZE_APPLY_ID 202
#define CAPTURE_ID 203
#define STRS_ID 205
#define STRS_CLOSE_ID 206
#define STRSCHK_ID 207
#define CB_ENSEMBLE 1004
#define CB_CFG_FB 1005
#define CB_QCELM_FB 1006
#define CB_CNTWALL_FB 1007
//using namespace std;
#include "myheader.h"
#include "myclass.h"
int istep = 0;
int mdmotion = 0;
int mdspeed = 10;
double dt = 1.0e-15;
int confwrint = 0, autocap = 0;
int itolfor = 1; float tolfor = 0.02;
//double rcut = 10.3176e-10; // cut off radius, in angstrom
//double rcut = 13.0e-10; // cut off radius, in angstrom
//double rcut2 = rcut * rcut;
float temp_set = 100.0;
float tempc = 0.0, cellx,celly,cellz,f_max,epotatom,dtm;
FILE *energyfile = fopen("energy.d","w");
float strs_xx,strs_yy,strs_zz,strs_xy,strs_yz,strs_zx;

Atom atom;
Cell cell;
Book book;
Tersoff tersoff;
ParamGEAM paramgeam;
Eammis eammis;
Dipole dipole;
Cond cond;
//Bre *bre = new Bre;
Bre bre;
Fire fire;

#ifdef CUDA
int *arrayDint;
int *arrayDrepatom;
double *arrayDrx, *arrayDry, *arrayDrz, *arrayDfx, *arrayDfy, *arrayDfz;
double *arrayDepot, *arrayDhmat, arrayHhmat[9];
int *arrayDalistnum, *arrayDalist;
int iarray[(NMAX+1)*(NBOOK+1)*4];
#endif

/*
void Atom::Distance(int i, int j)
{

}
*/

void md();
//void vscale();
void bookkeep();
//void e_force();
void readconfig(char* fname); 
void readqcelement(char* fname); 
void readqcelement(); 
void writedata();
void writedata_initialize();
void writeconfig(char* fname); void writeconfig_abs(char* fname);
void writeqcelement(char* fname);
void readsetdat(char* fname);
void instability();
void instability_QC();
void mk_helmat(int iel, double rx[], double ry[], double rz[], double mat[][3]);
void myGlutReshape(int x, int y);
void idle( void );
void createconfig();
void cnt_wall_set(); void cnt_wall_read(char* fname); void cnt_wall_write(char* fname);
void cnt_wall_discard();
void myGlutDisplay(void);
void bond_set();
void stretch_celladjust(float x, float y, float z);
void velocity_random(double target);
void get_first_arg(std::string &line, std::string &arg1);
int count_arg_number(std::string line);
#ifndef NOPNG
void capture();
#endif
void stresscheck(double eps_strschk);
void potential_set (int control);

float xy_aspect;
int   last_x, last_y;
float rotationX = 0.0, rotationY = 0.0;
float rotate[16] = {
  1,0,0,0,
  0,1,0,0,
  0,0,1,0,
  0,0,0,1
};
float obj_pos[] = {0.0, 0.0, 0.0};
float scl = 1.0;
float vscl = 0.2, vscl_force = 1.0;
int   main_window;


GLfloat red[] = {1.0, 0.0, 0.0, 1.0};
GLfloat yellow[] = {1.0, 1.0, 0.0, 1.0};
GLfloat white[] = {0.8, 0.8, 0.8, 1.0};
GLfloat gray[] = { 0.7, 0.7, 0.7 };
GLfloat blue[] = { 0.1, 0.1, 0.9 };
GLfloat green[] = { 0.0, 1.0, 0.0 };
GLfloat green2[] = { 0.0, 0.7, 0.0 };

//GLfloat *color[NOBJECTS];
GLfloat **color, **color0;
//int iatom[NREPLICA]; int repidx[NREPLICA]; int ibase, icnt;
int *iatom; int *repidx; int ibase, icnt;


/** These are the live variables passed into GLUI ***/
int   ortho = 1;
int   wireframe = 0;
int   draw_bond = 0, draw_bond_pbc = 0, draw_force = 0;
int   ensemble = 0;
int   relax_algo = 0;
int   config_type = 0;
char  config_atom[3] = "Al";
int   irepx=1,irepy=1,irepz=1;
int   icntm=8,icntn=0;
float cscnt = 50.0, rotz = 0.0, shiftz = 0.0;
float alat = 4.0;
int   imerge = 0;
char  current_config_name[100], current_qcelement_name[100];
char  cwdname[80] = "aaa"; 
char  *potstring_list[] = {"Morse", "GEAM", "Tersoff", "Brenner", "EAM Mishin", "Dipole", "ADP" };
int   ipottype = 0;
int   notrans = 0;
int   segments = 8;
int   radius = 8;
int   show_only_elem = 0;
int   show_axis = 0;
int   show_cell = 1;
int   show_cnt_wall = 0, show_cnt_wallv = 0;
int   show_cnt_wall_num = 1;
int   mode_cnt_corrugation = 0;
int   cnt_load_algo = 0;
float dexdt = 0.0, ex = 0.0;
float deydt = 0.0, ey = 0.0;
float dezdt = 0.0, ez = 0.0;
int repeat_lz; float repeat_lz_min, repeat_lz_max;
float cnt_pressure = 1.0, cnt_pressure_ftot = 0;
float cnt_ring_radius = 30.0, cnt_ring_fmax = 10.0, cnt_ring_sharpness = 2.0;
int   ievec = 0;
int   ievec_num = 1;
float evec_len = 10.0;
double mat[3][3];
float org_x = 0.0, org_y = 0.0, org_z = 0.0;
int size_w, size_h;
int b_state = 1;
float xx1, yy1, zz1, xx2, yy2, zz2, xx3, yy3, zz3, xx4, yy4, zz4;
GLuint objects;
int edit_elem_mode = 0, select_atom[10], select_atom_repidx[10];
int draw_replica = 0;
int hoge = 0;
float bondlength = 1.52; // in ang
int capture_count = 0;
float eps_strschk = 0.001;

// Using a std::string as a live variable is safe.
std::string text = "Test string..";

GLUI *glui, *filename_config_glui=0;
GLUI *filename_qcelement_glui=0;
GLUI *filename_cntwall_glui=0;
//GLUI *setdexdt_glui=0;
GLUI *edit_elem_glui=0;
GLUI *setparam_glui=0, *strs_glui=0;
GLUI *createconfig_glui=0;
GLUI_Checkbox   *checkbox;
//GLUI_Spinner    *spinner;
GLUI_Checkbox   *checkbox_pbcx;
GLUI_Checkbox   *checkbox_pbcy;
GLUI_Checkbox   *checkbox_pbcz;
GLUI_Checkbox   *checkbox_QC;
GLUI_Checkbox   *checkbox_Trans;
GLUI_Checkbox   *checkbox_show_only_elem;
//GLUI_Checkbox   *checkbox_axis;
GLUI_Checkbox   *checkbox_fatom;
GLUI_Checkbox   *checkbox_evec;
//GLUI_Checkbox   *checkbox_ortho;
GLUI_Spinner    *spinner_evec_num;
GLUI_Spinner    *spinner_evec_len;
GLUI_Spinner    *spinner_instcenter_num;
GLUI_RadioGroup *radio;
GLUI_RadioGroup *createconfig_radio;
GLUI_EditText   *edittext;
GLUI_CommandLine *filename_config, *filename_qcelement, *filename_cntwall;
//GLUI_CommandLine *setdexdt;
GLUI_Button *open_file_btn, *open_file_qcelement_btn, *cntwall_btn;
GLUI_Button *inst_btn;
GLUI_Button *reset_btn;
GLUI_Button *writeconfig_btn;
GLUI_Button *createconfig_btn;
GLUI_Button *writeqcelement_btn;
//GLUI_Button *setdexdt_btn;
GLUI_Button *mdswitch_btn;
GLUI_Button *edit_elem_btn;
GLUI_Button *edit_elem_xz_btn;
GLUI_Button *setparam_btn, *strs_btn;
GLUI_FileBrowser *config_fb, *qcelm_fb, *cntwall_fb;
GLUI_EditText *status_lx, *status_ly, *status_lz, *status_dt;

/* GLUI control callback                                                 */
void control_cb( int control )
{
  //printf( "callback: %d\n", control );
  /*
  printf( "             checkbox: %d\n", checkbox->get_int_val() );
  printf( "              spinner: %d\n", spinner->get_int_val() );
  printf( "             spinner2: %d\n", spinner2->get_int_val() );
  printf( "          radio group: %d\n", radio->get_int_val() );
  printf( "             ensemble: %d\n", ensemble );
  printf( "                 text: %s\n", edittext->get_text() );
  */
  //  std::cout<<ensemble<<std::endl;
  //  if (ievec_num>20) { ievec_num = 20; }
  //printf("control_cb %d\n",control);
  glutPostRedisplay();
  if (control == 0) { myGlutReshape( size_w, size_h ); }
  if (show_cnt_wall_num > atom.nwall) { show_cnt_wall_num = atom.nwall; GLUI_Master.sync_live_all(); }
  if (control == 10) { bond_set(); }
  if (control == CB_ENSEMBLE) { if (ensemble == 1) { velocity_random(temp_set); } }
  if (control == CB_CFG_FB) {
    char fname[60] = "aaa"; std::string fnames; fnames = config_fb->get_file();
    strcpy (fname, fnames.c_str());
    readconfig( fname ); readqcelement( current_qcelement_name );
    glutPostRedisplay();
    writedata_initialize(); }
  if (control == CB_QCELM_FB) {
    std::string text = qcelm_fb->get_file();
    char fname[60] = "aaa";
    strcpy (fname, text.c_str());
    readqcelement( fname );  }
  if (control == CB_CNTWALL_FB) {
    std::string text = cntwall_fb->get_file();
    char fname[60] = "aaa";
    strcpy (fname, text.c_str());
    cnt_wall_read( fname );  }
}

void pointer_cb ( GLUI_Control* control )
{
  if (control->get_id() == OPEN_FILE_ID) {
    filename_config_glui = GLUI_Master.create_glui( "Enter filename:", 0, 600, 150 );
    filename_config = new GLUI_CommandLine( filename_config_glui, "Config file:", NULL, -1, pointer_cb );
    filename_config->set_w( 300 );
    config_fb = new GLUI_FileBrowser(filename_config_glui, "", false, CB_CFG_FB, control_cb);
    config_fb->set_w(300);
    GLUI_Panel *panel = new GLUI_Panel(filename_config_glui, "", GLUI_PANEL_NONE);
    new GLUI_Checkbox(panel, "Merge", &imerge, 1, control_cb );
    new GLUI_Column(panel, false );
    new GLUI_Button(panel, "Close", FILE_CLOSE_ID, pointer_cb);
    filename_config_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == FILE_CLOSE_ID ) {
    open_file_btn->enable();
    control->glui->close();
  }
  else if (control->get_id() == OPEN_FILE_QCELEMENT_ID) {
    filename_qcelement_glui = GLUI_Master.create_glui( "Enter filename:", 0, 600, 150 );
    filename_qcelement = new GLUI_CommandLine( filename_qcelement_glui, "File:", NULL, -1, pointer_cb );
    filename_qcelement->set_w( 300 );
    qcelm_fb = new GLUI_FileBrowser(filename_qcelement_glui, "", false, CB_QCELM_FB, control_cb);
    qcelm_fb->set_w(300);
    GLUI_Panel *panel_qcelement = new GLUI_Panel(filename_qcelement_glui, "", GLUI_PANEL_NONE);
    new GLUI_Button(panel_qcelement, "Close", QCELEMENT_CLOSE_ID, pointer_cb);
    filename_qcelement_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == QCELEMENT_CLOSE_ID ) {
    open_file_qcelement_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == RESET_ID ) {
    //    org_x=0.0; org_y=0.0; org_z=0.0;
    //    rotationX=0.0; rotationY=0.0;
    //    for (int i=0; i<=15; i++) { rotate[i]=0; }
    //    rotate[0]=1;rotate[5]=1;rotate[10]=1;rotate[15]=1;
    for (int i=1; i<=atom.natom; i++) {
      atom.rx[i]=atom.rx_org[i];
      atom.ry[i]=atom.ry_org[i];
      atom.rz[i]=atom.rz_org[i];
      atom.vx[i]=0.0;atom.vy[i]=0.0;atom.vz[i]=0.0;
      atom.fx[i]=0.0;atom.fy[i]=0.0;atom.fz[i]=0.0;
    }
    for (int i=0; i<3; i++) {
      for (int j=0; j<3; j++) {
	cell.hmat[i][j]=cell.hmat_org[i][j];
      }
    }
    cellx=cell.hmat[0][0]/ang;celly=cell.hmat[1][1]/ang;cellz=cell.hmat[2][2]/ang;
    // give 'dummy' value for istep and then reset it (to sync display)
    istep = -1; glui->sync_live();
    istep =  0; glui->sync_live();
    ex = 0.0; dexdt = 0.0; ey = 0.0; deydt = 0.0; ez = 0.0; dezdt = 0.0;
    GLUI_Master.sync_live_all();
    bond_set();
    writedata_initialize();
  }
  else if ( control->get_id() == INST_ID ) {
    if (atom.QC) {
      instability_QC();
    } else {
      instability();
    }
  }
  else if ( control->get_id() == WRITECONFIG_ID ) {
    writeconfig("CONFIG.OUT"); writeconfig_abs("CONFIG.OUT.ABS");
  }
  else if ( control->get_id() == WRITEQCELEMENT_ID ) {
    writeqcelement("QCELEMENT.OUT");
  }
  else if ( control->get_id() == MDSWITCH_ID ) {
    if (mdmotion == 0) { glutPostRedisplay(); mdmotion = 1; } else { glutPostRedisplay();mdmotion = 0; }
  }
  else if ( control->get_id() == STRSCHK_ID ) {
    stresscheck((double)eps_strschk);
  }
  else if ( control == filename_config ) {
    std::string text = filename_config->get_text();
    char fname[60] = "aaa";
    strcpy (fname, text.c_str());
    readconfig( fname ); readqcelement( current_qcelement_name );
    glutPostRedisplay();
    writedata_initialize();
  }
  else if ( control == filename_qcelement ) {
    std::string text = filename_qcelement->get_text();
    char fname[60] = "aaa";
    strcpy (fname, text.c_str());
    readqcelement( fname );
  }
  else if ( control == filename_cntwall ) {
    std::string text = filename_cntwall->get_text();
    char fname[60] = "aaa";
    strcpy (fname, text.c_str());
    cnt_wall_read( fname );
  }
  //else if ( control == setdexdt ) {
  //  std::string text = setdexdt->get_text();
  //  char line[60] = "aaa"; strcpy (line, text.c_str());
  //  printf("Set dex/dt = %e ang\n",atof(line));
  //  dexdt = atof(line);
  //}
  else if ( control->get_id() == EDIT_ELEM_ID ) {
    edit_elem_glui = GLUI_Master.create_glui("Edit element", 0, 700, 50);
    for (int i=0; i<10; i++) { select_atom[i]=0; select_atom_repidx[i]=0; }
    edit_elem_mode=1;
    draw_replica=1;
    glutPostRedisplay();
    GLUI_Panel *panel_edit_elem = new GLUI_Panel(edit_elem_glui, "", GLUI_PANEL_NONE);
    //    new GLUI_EditText(panel_edit_elem, "1", GLUI_EDITTEXT_INT, NULL, 1, 
    new GLUI_EditText(panel_edit_elem, "1:", &select_atom[0], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "1-idx:", &select_atom_repidx[0], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "2:", &select_atom[1], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "2-idx:", &select_atom_repidx[1], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "3:", &select_atom[2], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "3-idx:", &select_atom_repidx[2], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "4:", &select_atom[3], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "4-idx:", &select_atom_repidx[3], 5, control_cb );
    new GLUI_Button(panel_edit_elem, "Take this", EDIT_ELEM_TAKE_ID, pointer_cb);
    new GLUI_Button(panel_edit_elem, "Close", EDIT_ELEM_CLOSE_ID, pointer_cb);
    edit_elem_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == EDIT_ELEM_TAKE_ID ) {
    if ((select_atom[0]!=0)&&(select_atom[1]!=0)&&(select_atom[2]!=0)&&(select_atom[3]!=0)) {
      printf("New element: %d %d %d %d  %d %d %d %d\n",
	     select_atom[0],select_atom[1],select_atom[2],select_atom[3],
	     select_atom_repidx[0],select_atom_repidx[1],select_atom_repidx[2],select_atom_repidx[3]);
      int i = atom.nelem+1;
      atom.elem_v     = (int **)realloc(atom.elem_v,     sizeof(int*)*(i+1));
      atom.elem_v_rep = (int **)realloc(atom.elem_v_rep, sizeof(int*)*(i+1));
      atom.elem_v[i]     = (int *)malloc(sizeof(int)*5);
      atom.elem_v_rep[i] = (int *)malloc(sizeof(int)*5);
      atom.elem_v[i][1]=select_atom[0]; atom.elem_v_rep[i][1]=select_atom_repidx[0];
      atom.elem_v[i][2]=select_atom[1]; atom.elem_v_rep[i][2]=select_atom_repidx[1];
      atom.elem_v[i][3]=select_atom[2]; atom.elem_v_rep[i][3]=select_atom_repidx[2];
      atom.elem_v[i][4]=select_atom[3]; atom.elem_v_rep[i][4]=select_atom_repidx[3];
      atom.nelem = i;
      readqcelement();
      for (int ii=0; ii<10; ii++) { select_atom[ii]=0; select_atom_repidx[ii]=0; }
      for (int ii=1; ii<=atom.natom+icnt; ii++) { memcpy(color[ii],yellow,sizeof(GLfloat)*4); }
      GLUI_Master.sync_live_all();
      glutPostRedisplay();
    }
  }
  else if ( control->get_id() == EDIT_ELEM_CLOSE_ID ) {
    edit_elem_mode=0;
    draw_replica=0;
    for (int i=1; i<=atom.natom+icnt; i++) { memcpy(color[i],yellow,sizeof(GLfloat)*4); }
    glutPostRedisplay();
    edit_elem_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == EDIT_ELEM_XZ_ID ) {
    edit_elem_glui = GLUI_Master.create_glui("Edit element (xz-plane mode)", 0, 700, 50);
    for (int i=0; i<10; i++) { select_atom[i]=0; select_atom_repidx[i]=0; }
    edit_elem_mode=2;
    draw_replica=2;
    glutPostRedisplay();
    GLUI_Panel *panel_edit_elem = new GLUI_Panel(edit_elem_glui, "", GLUI_PANEL_NONE);
    new GLUI_EditText(panel_edit_elem, "1:", &select_atom[0], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "1-idx:", &select_atom_repidx[0], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "2:", &select_atom[1], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "2-idx:", &select_atom_repidx[1], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "3:", &select_atom[2], 5, control_cb );
    new GLUI_EditText(panel_edit_elem, "3-idx:", &select_atom_repidx[2], 5, control_cb );
    new GLUI_Button(panel_edit_elem, "Take this", EDIT_ELEM_XZ_TAKE_ID, pointer_cb);
    new GLUI_Button(panel_edit_elem, "Close", EDIT_ELEM_XZ_CLOSE_ID, pointer_cb);
    edit_elem_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == EDIT_ELEM_XZ_TAKE_ID ) {
    if ((select_atom[0]!=0)&&(select_atom[1]!=0)&&(select_atom[2]!=0)) {
      //      printf("New element: %d %d %d %d  %d %d %d %d\n",
      //	     select_atom[0],select_atom[1],select_atom[2],select_atom[3],
      //	     select_atom_repidx[0],select_atom_repidx[1],select_atom_repidx[2],select_atom_repidx[3]);
      int i = atom.nelem+3;
      atom.elem_v     = (int **)realloc(atom.elem_v,     sizeof(int*)*(i+1));
      atom.elem_v_rep = (int **)realloc(atom.elem_v_rep, sizeof(int*)*(i+1));
      for (int ii=atom.nelem+1; ii<=atom.nelem+3; ii++) {
	atom.elem_v[ii]     = (int *)malloc(sizeof(int)*5);
	atom.elem_v_rep[ii] = (int *)malloc(sizeof(int)*5);
      }
      i = atom.nelem+1;
      atom.elem_v[i][1]=select_atom[0]; atom.elem_v_rep[i][1]=select_atom_repidx[0];
      atom.elem_v[i][2]=select_atom[1]; atom.elem_v_rep[i][2]=select_atom_repidx[1];
      atom.elem_v[i][3]=select_atom[2]; atom.elem_v_rep[i][3]=select_atom_repidx[2];
      atom.elem_v[i][4]=select_atom[2]; atom.elem_v_rep[i][4]=select_atom_repidx[2]+2;
      i = atom.nelem+2;
      atom.elem_v[i][1]=select_atom[0]; atom.elem_v_rep[i][1]=select_atom_repidx[0];
      atom.elem_v[i][2]=select_atom[1]; atom.elem_v_rep[i][2]=select_atom_repidx[1];
      atom.elem_v[i][3]=select_atom[1]; atom.elem_v_rep[i][3]=select_atom_repidx[1]+2;
      atom.elem_v[i][4]=select_atom[2]; atom.elem_v_rep[i][4]=select_atom_repidx[2]+2;
      i = atom.nelem+3;
      atom.elem_v[i][1]=select_atom[0]; atom.elem_v_rep[i][1]=select_atom_repidx[0];
      atom.elem_v[i][2]=select_atom[0]; atom.elem_v_rep[i][2]=select_atom_repidx[0]+2;
      atom.elem_v[i][3]=select_atom[1]; atom.elem_v_rep[i][3]=select_atom_repidx[1]+2;
      atom.elem_v[i][4]=select_atom[2]; atom.elem_v_rep[i][4]=select_atom_repidx[2]+2;
      atom.nelem = i;
      readqcelement();
      for (int ii=0; ii<10; ii++) { select_atom[ii]=0; select_atom_repidx[ii]=0; }
      for (int ii=1; ii<=atom.natom+icnt; ii++) { memcpy(color[ii],yellow,sizeof(GLfloat)*4); }
      GLUI_Master.sync_live_all();
      glutPostRedisplay();
    }
  }
  else if ( control->get_id() == EDIT_ELEM_XZ_CLOSE_ID ) {
    edit_elem_mode=0;
    draw_replica=0;
    for (int i=1; i<=atom.natom+icnt; i++) { memcpy(color[i],yellow,sizeof(GLfloat)*4); }
    glutPostRedisplay();
    edit_elem_xz_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == SETPARAM_ID ) {
    setparam_glui = GLUI_Master.create_glui("Set parameters", 0, 700, 50);
    glutPostRedisplay();
    GLUI_Panel *setparam_panel01 = new GLUI_Panel(setparam_glui, "", GLUI_PANEL_NONE);
    new GLUI_Checkbox(setparam_panel01, "Wireframe", &wireframe, 1, control_cb );
    new GLUI_Checkbox(setparam_panel01, "Ortho", &ortho, 0, control_cb);
    new GLUI_Column(setparam_panel01, false );
    new GLUI_Checkbox(setparam_panel01, "Show axis", &show_axis);
    new GLUI_Checkbox(setparam_panel01, "Show cell", &show_cell);
    new GLUI_Column(setparam_panel01, false );
    GLUI_Spinner *spinner2  = new GLUI_Spinner(setparam_panel01, "Radius:", &radius, 5, control_cb );
    spinner2->set_int_limits( 1, 20 );
    GLUI_Panel *setparam_panel011 = new GLUI_Panel(setparam_glui, "", GLUI_PANEL_NONE);
    new GLUI_Checkbox(setparam_panel011, "Draw bond", &draw_bond, 10, control_cb);
    new GLUI_Checkbox(setparam_panel011, "Bond-PBC", &draw_bond_pbc, 10, control_cb);
    GLUI_EditText *spinner5 = new GLUI_EditText(setparam_panel011,"Bond length",GLUI_EDITTEXT_FLOAT,&bondlength,10,control_cb);
    spinner5->set_float_limits( 0.0, 10.0 );
    new GLUI_Column(setparam_panel011, false );
    new GLUI_Checkbox(setparam_panel011, "Draw Force", &draw_force, 10, control_cb);
    new GLUI_EditText(setparam_panel011, "F-arw length", &vscl_force);
    GLUI_Panel *setparam_panel02 = new GLUI_Panel(setparam_glui, "", GLUI_PANEL_NONE );
    GLUI_Spinner *spinner3 = new GLUI_Spinner(setparam_panel02, "Redraw itvl:", &mdspeed);
    spinner3->set_int_limits( 1, 50 );
    new GLUI_Column(setparam_panel02, false );
    GLUI_Spinner *spinner4 = new GLUI_Spinner(setparam_panel02, "B-keep itvl:", &book.nbk);
    spinner4->set_int_limits( 5, 500 );
    GLUI_Panel *setparam_panel012 = new GLUI_Panel(setparam_glui, "", GLUI_PANEL_NONE);
    GLUI_Panel *setparam_panel020 = new GLUI_Panel(setparam_panel012, "Relax algo");
    GLUI_RadioGroup *relax_radio = new GLUI_RadioGroup(setparam_panel020,&relax_algo,0,control_cb );
    new GLUI_RadioButton(relax_radio, "GLOC" );
    new GLUI_RadioButton(relax_radio, "FIRE" );
    new GLUI_Column(setparam_panel012, false );
    new GLUI_EditText(setparam_panel012, "CONF Wr itvl", &confwrint);
    new GLUI_Checkbox(setparam_panel012, "Auto capture", &autocap);
    new GLUI_Column(setparam_panel012, false );
    new GLUI_Checkbox(setparam_panel012, "Stop MD by Fmax", &itolfor);
    new GLUI_EditText(setparam_panel012, "Fmax tlrc (eV/A)", &tolfor);
    GLUI_Rollout *setparam_panel021 = new GLUI_Rollout(setparam_glui, "Deformation settings", false);
    GLUI_Panel *setparam_panel0211 = new GLUI_Panel(setparam_panel021, "", GLUI_PANEL_NONE);
    GLUI_EditText *text_setdexdt = new GLUI_EditText(setparam_panel0211, "ex(/ps):", &dexdt);
    text_setdexdt->set_float_limits(-1.0,1.0);
    new GLUI_Column(setparam_panel0211, false );
    GLUI_EditText *text_setdeydt = new GLUI_EditText(setparam_panel0211, "ey(/ps):", &deydt);
    text_setdeydt->set_float_limits(-1.0,1.0);
    new GLUI_Column(setparam_panel0211, false );
    GLUI_EditText *text_setdezdt = new GLUI_EditText(setparam_panel0211, "ez(/ps):", &dezdt);
    text_setdezdt->set_float_limits(-1.0,1.0);
    GLUI_Panel *setparam_panel0212 = new GLUI_Panel(setparam_panel021, "", GLUI_PANEL_NONE);
    new GLUI_Checkbox(setparam_panel0212, "Repeat Lz", &repeat_lz);
    new GLUI_Column(setparam_panel0212, false );
    GLUI_EditText *text_lz_min = new GLUI_EditText(setparam_panel0212, "Lz(min):", &repeat_lz_min);
    new GLUI_Column(setparam_panel0212, false );
    GLUI_EditText *text_lz_max = new GLUI_EditText(setparam_panel0212, "Lz(max):", &repeat_lz_max);
    /*
    GLUI_Panel *setparam_panel0212 = new GLUI_Panel(setparam_panel021, "", GLUI_PANEL_NONE);
    GLUI_EditText *text_setcellx = new GLUI_EditText(setparam_panel0212, "Lx", &cellx);
    new GLUI_Column(setparam_panel0212, false );
    GLUI_EditText *text_setcelly = new GLUI_EditText(setparam_panel0212, "Ly", &celly);
    new GLUI_Column(setparam_panel0212, false );
    GLUI_EditText *text_setcellz = new GLUI_EditText(setparam_panel0212, "Lz", &cellz);
    new GLUI_Button(setparam_panel0212, "Apply", CELLSIZE_APPLY_ID, pointer_cb);
    */
    GLUI_Rollout *setparam_panel03 = new GLUI_Rollout(setparam_glui, "Special settings for CNT", false);
    new GLUI_Checkbox(setparam_panel03, "Corrugation mode", &mode_cnt_corrugation);
    new GLUI_Checkbox(setparam_panel03, "Show CNT wall", &show_cnt_wall);
    new GLUI_Checkbox(setparam_panel03, "Show CNT n-vec", &show_cnt_wallv);
    new GLUI_EditText(setparam_panel03, "n-vec length", &vscl);
    GLUI_Panel *corr_radio_panel = new GLUI_Panel(setparam_panel03, "Loading type" );
    GLUI_RadioGroup *corr_radio = new GLUI_RadioGroup(corr_radio_panel,&cnt_load_algo,0,control_cb );
    new GLUI_RadioButton(corr_radio, "Wall" );
    new GLUI_RadioButton(corr_radio, "Ring" );
    new GLUI_Column(setparam_panel03, false );
    GLUI_Panel *corr_wall_panel = new GLUI_Panel(setparam_panel03, "Wall" );
    GLUI_Spinner *spinner6 = new GLUI_Spinner(corr_wall_panel, "CNT wall #", &show_cnt_wall_num,5,control_cb);
    spinner6->set_int_limits( 0, NMAX*3 ); spinner6->set_speed( 0.01 );
    GLUI_Spinner *spinner7 = new GLUI_Spinner(corr_wall_panel, "Pressure", &cnt_pressure,5,control_cb);
    spinner7->set_speed( 0.01 );
    GLUI_Panel *corr_ring_panel = new GLUI_Panel(setparam_panel03, "Ring" );
    new GLUI_EditText(corr_ring_panel, "Radius(A)", &cnt_ring_radius);
    new GLUI_EditText(corr_ring_panel, "Fmax(N)",   &cnt_ring_fmax);
    new GLUI_EditText(corr_ring_panel, "Sharpness", &cnt_ring_sharpness);
    //spinner7->set_float_limits( 0.0, 100.0);

    GLUI_Panel *setparam_panel10 = new GLUI_Panel(setparam_glui, "", GLUI_PANEL_NONE );
    new GLUI_Button(setparam_panel10, "Read SETDAT", SETPARAM_READ_ID, pointer_cb);
    new GLUI_Column(setparam_panel10, false );
    new GLUI_Button(setparam_panel10, "Close", SETPARAM_CLOSE_ID, pointer_cb);
    setparam_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == STRS_ID ) {
    strs_glui = GLUI_Master.create_glui("Stress", 0, 700, 50);
    glutPostRedisplay();
    GLUI_Panel *strs_panel01 = new GLUI_Panel(strs_glui, "", GLUI_PANEL_NONE);
    new GLUI_StaticText( strs_panel01, "Stress in MPa" );
    GLUI_Panel *strs_panel011 = new GLUI_Panel(strs_panel01, "", GLUI_PANEL_NONE);
    GLUI_EditText *str1 = new GLUI_EditText(strs_panel011, "xx", &strs_xx);
    new GLUI_Column(strs_panel011, false ); str1->set_w(150);
    GLUI_EditText *str2 = new GLUI_EditText(strs_panel011, "yy", &strs_yy);
    new GLUI_Column(strs_panel011, false );str2->set_w(150);
    GLUI_EditText *str3 = new GLUI_EditText(strs_panel011, "zz", &strs_zz);
    str3->set_w(150);
    GLUI_Panel *strs_panel012 = new GLUI_Panel(strs_panel01, "", GLUI_PANEL_NONE);
    GLUI_EditText *str4 = new GLUI_EditText(strs_panel012, "xy", &strs_xy);
    new GLUI_Column(strs_panel012, false ); str4->set_w(150);
    GLUI_EditText *str5 = new GLUI_EditText(strs_panel012, "yz", &strs_yz);
    new GLUI_Column(strs_panel012, false ); str5->set_w(150);
    GLUI_EditText *str6 = new GLUI_EditText(strs_panel012, "zx", &strs_zx);
    str6->set_w(150);
    GLUI_Panel *strs_panel015 = new GLUI_Panel(strs_panel01, "", GLUI_PANEL_NONE);
    new GLUI_EditText(strs_panel015, "Stress check with de", &eps_strschk);
    new GLUI_Column(strs_panel015, false );
    new GLUI_Button(strs_panel015, "Check", STRSCHK_ID, pointer_cb);
    new GLUI_Button(strs_panel01, "Close", STRS_CLOSE_ID, pointer_cb);
    strs_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == STRS_CLOSE_ID ) {
    strs_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == SETPARAM_READ_ID ) {
    readsetdat("SETDAT");
  }
  else if ( control->get_id() == SETPARAM_CLOSE_ID ) {
    setparam_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == CELLSIZE_APPLY_ID ) {
    stretch_celladjust(cellx,celly,cellz);
    glui->sync_live();
  }
  else if ((control == status_lx)||(control == status_ly)||(control == status_lz)) {
    stretch_celladjust(cellx,celly,cellz);
    glui->sync_live();
  }
  else if (control == status_dt) {
    dt = (double)dtm*1e-15;
  }
  else if (control->get_id() == CREATECONFIG_ID) {
    createconfig_glui = GLUI_Master.create_glui("Create config", 0, 700, 50);
    glutPostRedisplay();
    GLUI_Panel *createconfig_panel01 = new GLUI_Panel( createconfig_glui, "", GLUI_PANEL_NONE);
    GLUI_EditText *createconfig_asp = new GLUI_EditText(createconfig_panel01,"Atom", config_atom);
    GLUI_Listbox *potlist2 = new GLUI_Listbox(createconfig_panel01, "Potential", &ipottype,0,potential_set);
    for (int i=0; i<MAXPOTTYPE; i++) { potlist2->add_item(i, potstring_list[i]); }
    createconfig_radio = new GLUI_RadioGroup( createconfig_panel01,&config_type,0,control_cb );
    new GLUI_RadioButton( createconfig_radio, "FCC" );
    new GLUI_RadioButton( createconfig_radio, "BCC" );
    new GLUI_RadioButton( createconfig_radio, "Diamond" );
    new GLUI_RadioButton( createconfig_radio, "Nanotube" );
    GLUI_Spinner *createconfig_spinner10
      = new GLUI_Spinner(createconfig_panel01, "NT Rotation (z) [deg]", &rotz, 0, control_cb );
    createconfig_spinner10->set_float_limits( 0.0, 360.0 );
    GLUI_Spinner *createconfig_spinner11
      = new GLUI_Spinner(createconfig_panel01, "NT Shift (z) [%]", &shiftz, 0, control_cb );
    createconfig_spinner11->set_float_limits( 0.0, 100.0 );
    new GLUI_Column(createconfig_panel01, false );
    GLUI_Spinner *createconfig_spinner1
      = new GLUI_Spinner(createconfig_panel01, "# of rep in x", &irepx, 0, control_cb );
    createconfig_spinner1->set_int_limits( 1, 20 );
    GLUI_Spinner *createconfig_spinner2
      = new GLUI_Spinner(createconfig_panel01, "# of rep in y", &irepy, 0, control_cb );
    createconfig_spinner2->set_int_limits( 1, 20 );
    GLUI_Spinner *createconfig_spinner3
      = new GLUI_Spinner(createconfig_panel01, "# of rep in z", &irepz, 0, control_cb );
    createconfig_spinner3->set_int_limits( 1, 20 );
    GLUI_Spinner *createconfig_spinner4
      = new GLUI_Spinner(createconfig_panel01, "m of (m,n)", &icntm, 0, control_cb );
    createconfig_spinner4->set_int_limits( 0, 50 );
    GLUI_Spinner *createconfig_spinner5
      = new GLUI_Spinner(createconfig_panel01, "n of (m, n)", &icntn, 0, control_cb );
    createconfig_spinner5->set_int_limits( 0, 50 );
    GLUI_Spinner *createconfig_spinner7
      = new GLUI_Spinner(createconfig_panel01, "NT cell size (x/y) [ang]", &cscnt, 0, control_cb );
    createconfig_spinner7->set_float_limits( 10.0f, 200.0 );
    GLUI_Spinner *createconfig_spinner6
      = new GLUI_Spinner(createconfig_panel01, "Lattice const. [ang]", &alat, 0, control_cb );
    createconfig_spinner6->set_float_limits( 0.0f, 100.0 );

    GLUI_Panel *createconfig_panel02 = new GLUI_Panel(createconfig_glui, "", GLUI_PANEL_NONE );
    new GLUI_Button(createconfig_panel02, "Set CNT wall", CNTWALL_DO_ID, pointer_cb);
    new GLUI_Column(createconfig_panel02, false );
    cntwall_btn = new GLUI_Button(createconfig_panel02, "Read wall data", CNTWALL_READ_ID, pointer_cb);
    new GLUI_Column(createconfig_panel02, false );
    new GLUI_Button(createconfig_panel02, "Write wall data", CNTWALL_WRITE_ID, pointer_cb);
    //new GLUI_Checkbox(createconfig_panel02, "Show CNT wall", &show_cnt_wall);

    GLUI_Panel *createconfig_panel10 = new GLUI_Panel(createconfig_glui, "", GLUI_PANEL_NONE );
    new GLUI_Button(createconfig_panel10, "Create", CREATECONFIG_DO_ID, pointer_cb);
    new GLUI_Column(createconfig_panel10, false );
    new GLUI_Button(createconfig_panel10, "Close", CREATECONFIG_CLOSE_ID, pointer_cb);
    createconfig_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == CREATECONFIG_CLOSE_ID ) {
    createconfig_btn->enable();
    control->glui->close();
  }
  else if ( control->get_id() == CREATECONFIG_DO_ID ) {
    createconfig();
    glutPostRedisplay();
  }
  else if ( control->get_id() == CNTWALL_DO_ID ) {
    cnt_wall_set();
    glutPostRedisplay();
  }
  else if ( control->get_id() == CNTWALL_READ_ID ) {
    //  cnt_wall_read("CNTWALL");
    //  glutPostRedisplay();
    //}

    //else if (control->get_id() == OPEN_FILE_QCELEMENT_ID) {
    filename_cntwall_glui = GLUI_Master.create_glui( "CNTWALL filename", 0, 600, 150 );
    filename_cntwall = new GLUI_CommandLine( filename_cntwall_glui, "File:", NULL, -1, pointer_cb );
    filename_cntwall->set_w( 300 );
    cntwall_fb = new GLUI_FileBrowser(filename_cntwall_glui, "", false, CB_CNTWALL_FB, control_cb);
    cntwall_fb->set_w(300);
    GLUI_Panel *panel_cntwall = new GLUI_Panel(filename_cntwall_glui, "", GLUI_PANEL_NONE);
    new GLUI_Button(panel_cntwall, "Close", CNTWALL_CLOSE_ID, pointer_cb);
    filename_cntwall_glui->set_main_gfx_window( main_window );
    control->disable();
  }
  else if ( control->get_id() == CNTWALL_CLOSE_ID ) {
    cntwall_btn->enable();
    control->glui->close();
  }

  else if ( control->get_id() == CNTWALL_WRITE_ID ) {
    cnt_wall_write("CNTWALL.SAVE");
    glutPostRedisplay();
  }
#ifndef NOPNG
  else if ( control->get_id() == CAPTURE_ID) {
    capture();
    glutPostRedisplay();
  }
#endif
}

/**************************************** myGlutKeyboard() **********/
void myGlutKeyboard(unsigned char Key, int x, int y)
{
  switch(Key)
  {
    // A few keys here to test the sync_live capability.
  case 'e':
    // Cycle through ensemble types
    ++ensemble %= 2;
    GLUI_Master.sync_live_all();
    break;
  case 'w':
    // Toggle wireframe mode
    wireframe = !wireframe;
    GLUI_Master.sync_live_all();
    break;
  case 'r':
    org_x=0.0; org_y=0.0; org_z=0.0;
    rotationX=0.0; rotationY=0.0;
    for (int i=0; i<=15; i++) { rotate[i]=0; }
    rotate[0]=1;rotate[6]=-1;rotate[9]=1;rotate[15]=1;
    /*
    for (int i=1; i<=atom.natom; i++) {
      atom.rx[i]=atom.rx_org[i]; atom.ry[i]=atom.ry_org[i]; atom.rz[i]=atom.rz_org[i];
      atom.vx[i]=0.0;atom.vy[i]=0.0;atom.vz[i]=0.0;
      atom.fx[i]=0.0;atom.fy[i]=0.0;atom.fz[i]=0.0;  }
    for (int i=0; i<3; i++) {
      for (int j=0; j<3; j++) {
	cell.hmat[i][j]=cell.hmat_org[i][j];  } }
    istep = 0;
    */
    glui->sync_live();

    writedata_initialize();

    break;
  case 27: 
  case 'q':
    exit(0);
    break;
  };
  glutPostRedisplay();
}

void potential_set (int control)
{
  printf("Potential: No. %d, %s\n",ipottype,potstring_list[ipottype]);
  //strcpy(atom.potential_func, potstring_list[ipottype]);
  std::string line = std::string(potstring_list[ipottype]);
  std::string arg1, arg2; int narg = count_arg_number(line);
  if (narg==1) { get_first_arg(line,arg1);
    strcpy(atom.potential_func, arg1.c_str());
    strcpy(atom.potential_arg, "");
  } else { get_first_arg(line,arg1); get_first_arg(line,arg2);
    strcpy(atom.potential_func, arg1.c_str());
    strcpy(atom.potential_arg,  arg2.c_str()); }
  book.algo = 1;
  if (strcmp(atom.potential_func,"Tersoff")==0) { book.algo = 2; }
  if (strcmp(atom.potential_func,"Brenner")==0) { book.algo = 3; }
}

/***************************************** myGlutMenu() ***********/

void myGlutMenu( int value )
{
  myGlutKeyboard( value, 0, 0);
}

void idle( void )
{
  glutPostRedisplay();

  glui->sync_live();
}

void myGlutIdle( void )
{
  if ( glutGetWindow() != main_window ) 
    glutSetWindow(main_window); 
  glutPostRedisplay();
  glui->sync_live();
}

/***************************************** myGlutMouse() **********/

void myGlutMouse(int button, int button_state, int x, int y )
{
  static GLuint selection[SELECTIONS];
  static GLint hits = 0;

  switch (button) {
  case GLUT_LEFT_BUTTON:
    if (button_state == GLUT_DOWN) {
      GLuint *ptr; GLint vp[4];
      glSelectBuffer(SELECTIONS, selection);
      glRenderMode(GL_SELECT);
      glInitNames();
      glPushName(-1);
      glMatrixMode(GL_PROJECTION);
      glPushMatrix();
      glLoadIdentity();
      glGetIntegerv(GL_VIEWPORT, vp);
      gluPickMatrix(x, vp[3] - y - 1, 1, 1, vp);
      if (ortho) {
	glOrtho(-size_w/200.0, size_w/200.0, -size_h/200.0, size_h/200.0, -100.0, 100.0);
      } else {
	gluPerspective(30.0, (double)vp[2] / (double)vp[3], 1.0, 100.0);
	glTranslated(0.0, 0.0, -1.0);
      }
      glMatrixMode(GL_MODELVIEW);
      //      for (int i = 0; i < atom.natom; i++) {
      for (int i = 1; i <= atom.natom; i++) {
	glLoadName(i);
	glCallList(objects + i);
      }
      if (draw_replica>0) {
	for (int i = 1; i <= icnt; i++) {
	  glLoadName(ibase+i);
	  glCallList(ibase + i);
	}
      }
      glMatrixMode(GL_PROJECTION);
      glPopMatrix();
      glMatrixMode(GL_MODELVIEW);
      hits = glRenderMode(GL_RENDER);
      //printf("hits = %d\n",hits);
      ptr = selection;
      //      for (int i = 0; i < hits; i++) {
      //      printf("selection is %d\n",*ptr);
      if (hits>0) {
	unsigned int j, n = ptr[0];
	double near = (double)ptr[1] / (double)0x7fffffff;
	double far  = (double)ptr[2] / (double)0x7fffffff;
	ptr += 3;
	//printf("*ptr is %d  ibase is %d\n",*ptr,ibase);
	for (j = 0; j < n; j++) {
	  if (*ptr<=atom.natom) {
	    printf("Atom = %d [%s] Pos (nm): %f %f %f\n",
		   *ptr,atom.asp[*ptr],atom.rx[*ptr]*1e9,atom.ry[*ptr]*1e9,atom.rz[*ptr]*1e9);
	    printf("               F (eV/A): %f %f %f\n",
		   atom.fx[*ptr]/ev*ang,atom.fy[*ptr]/ev*ang,atom.fz[*ptr]/ev*ang);
	    printf("               Ene (eV): %f\n",
		   atom.epot[*ptr]/ev);
	  } else {
	    //int ia=iatom[*ptr-atom.natom-objects];
	    int ia=iatom[*ptr-atom.natom-objects];
	    printf("Replica Atom = %d  Pos: %f %f %f  Rep-index: %d\n",
		   ia,atom.rx[ia]*1e9,atom.ry[ia]*1e9,atom.rz[ia]*1e9,
		   //repidx[*ptr-atom.natom-objects]);
		   repidx[*ptr-objects]);
	  }
	    
	  if (edit_elem_mode>0) {
	    int iimax=4; if (edit_elem_mode==2) { iimax=3; }
	    int ifnd = 0;
	    for (int ii=0; ii<iimax; ii++) {
	      int ix = *ptr; int iy = 0;
	      if (ix>atom.natom) { ix=iatom[*ptr-atom.natom-objects]; iy = repidx[*ptr-atom.natom-objects]; }
	      //if (*ptr == select_atom[ii]) {
	      if ((select_atom[ii] == ix)&&(select_atom_repidx[ii] == iy)) {
		if (*ptr<=atom.natom) {
		  memcpy(color[*ptr],yellow,sizeof(GLfloat)*4);
		} else {
		  memcpy(color[*ptr-objects],yellow,sizeof(GLfloat)*4);
		}
		select_atom[ii] = 0; select_atom_repidx[ii] = 0;
		ifnd = 1;
		break;
	      }
	    }
	    if (ifnd==0) {
	      for (int ii=0; ii<iimax; ii++) {
		if (select_atom[ii] == 0) {
		  if (*ptr<=atom.natom) {
		    memcpy(color[*ptr],green,sizeof(GLfloat)*4);
		    //printf("Painting GREEN *ptr<=atom.natom %d\n",*ptr);
		  } else {
		    //memcpy(color[*ptr-atom.natom-objects],green,sizeof(GLfloat)*4);
		    memcpy(color[*ptr-objects],green,sizeof(GLfloat)*4);
		    //printf("Painting GREEN *ptr>atom.natom %d\n",*ptr-objects);
		  }
		  if (*ptr<=atom.natom) {
		    select_atom[ii]=*ptr; select_atom_repidx[ii]=0;
		  } else {
		    //select_atom[ii]=*ptr;
		    select_atom[ii]=iatom[*ptr-atom.natom-objects];
		    select_atom_repidx[ii]=repidx[*ptr-atom.natom-objects];
		  }
		  printf("Selected Atom %d = %d \n", ii, select_atom[ii]);
		  break;
		}
	      }
	    }

	  } else { // if not edit_elem_mode
	    memcpy(color[*ptr],blue,sizeof(GLfloat)*4);
	  }
	}
	GLUI_Master.sync_live_all();
      }
    }
    else {
      GLuint *ptr = selection;
      int i;
      //      for (i = 0; i < hits; i++) {
      if (hits>0) {
	unsigned int j, n = ptr[0];
	ptr += 3;
	for (j = 0; j < n; j++) {
	  if (edit_elem_mode>0) {

	  } else { // return to original color
	    //memcpy(color[*ptr],yellow,sizeof(GLfloat)*4);
	    memcpy(color[*ptr],color0[*ptr],sizeof(GLfloat)*4);
	  }
	}
      }
    }
    glutPostRedisplay();
    break;

  case GLUT_MIDDLE_BUTTON:
    glutIdleFunc(idle);
    mdmotion = 1;
    break;
  case GLUT_RIGHT_BUTTON:
    glutIdleFunc(0);
    mdmotion = 0;
    break;
    /*  
  case GLUT_MIDDLE_BUTTON:
    if (button_state == GLUT_DOWN) {
      glutIdleFunc(0);
      glutPostRedisplay();
      mdmotion = 1;
    } else {
      //      glutPostRedisplay();
      glutIdleFunc(0);
      mdmotion = 0;
    }      
    break;
    */
  }
}

/***************************************** myGlutMotion() **********/
void myGlutMotion(int x, int y )
{
  //glutPostRedisplay(); 
}

/**************************************** myGlutReshape() *************/
void myGlutReshape( int x, int y )
{
  xy_aspect = (float)x / (float)y;
  glViewport( 0, 0, x, y);
  glMatrixMode(GL_PROJECTION);// <==
  glLoadIdentity();
  if (ortho) {
    GLfloat light0_ambient[] =  {0.1f, 0.1f, 0.3f, 1.0f};
    GLfloat light0_diffuse[] =  {.6f, .6f, 1.0f, 1.0f};
    GLfloat light0_position[] = {200.0f, 200.0f, 200-6.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
    glOrtho(-x/200.0, x/200.0, -y/200.0, y/200.0, -100.0, 100.0);
  } else {
    GLfloat light0_ambient[] =  {0.1f, 0.1f, 0.3f, 1.0f};
    GLfloat light0_diffuse[] =  {.6f, .6f, 1.0f, 1.0f};
    GLfloat light0_position[] = {20.0f, 20.0f, 200-4.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
    gluPerspective(30.0, (double)xy_aspect, 1.0, 100.0);
    glTranslated(0.0, 0.0, -1.0);
  }
  glMatrixMode(GL_MODELVIEW);// <==
  glutPostRedisplay();
  size_w = x; size_h = y;
}


/**************************************** main() ********************/
int main(int argc, char* argv[])
{
  /*   Initialize GLUT and create window  */
  // This must be done before READCONFIG, otherwise it crashes in some systems.
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
  glutInitWindowPosition( 50, 50 );
  glutInitWindowSize( 600, 600 );
  main_window = glutCreateWindow( "MD viewer" );
  //

#ifdef __linux__
  if (argc>1) {
    printf("Change directory to %s\n",argv[1]); chdir(argv[1]); }
  // default initial configuration
  strcpy(atom.potential_func, "GEAM"); book.algo = 1;
  if (argc<=2) {
    readsetdat("SETDAT"); readconfig("CONFIG"); //readqcelement("QCELEMENT");
  } else if (argc==3) {
    readsetdat("SETDAT"); readconfig(argv[2]); //readqcelement("QCELEMENT");
  } else if (argc==4) {
    readsetdat(argv[3]); readconfig(argv[2]); //readqcelement("QCELEMENT");
  }
#else
  readsetdat("SETDAT"); readconfig("CONFIG");
#endif
  getcwd(cwdname,80);
  printf("Current Working Directory = %s\n",cwdname);
  writedata_initialize();

  for (int i=1; i<=atom.natom; i++) {
    atom.vx[i] = 0.0e3;   atom.vy[i] = 0.0e3  ; atom.vz[i] = 0.0e3;
  }
  for (int i=1; i<=atom.natom; i++) {
    atom.rx_org[i]=atom.rx[i];atom.ry_org[i]=atom.ry[i];atom.rz_org[i]=atom.rz[i];
  }

  //  std::ofstream fouttraj("trajectory.d");
  //  std::ofstream fout("energy.d");

  // Then GLUT functions contiune... 
  glutDisplayFunc( myGlutDisplay );
  glutReshapeFunc( myGlutReshape );  
  glutKeyboardFunc( myGlutKeyboard );
  glutMotionFunc( myGlutMotion );
  glutMouseFunc( myGlutMouse );

  /*       Set up OpenGL lights           */

  //GLfloat light0_ambient[] =  {0.1f, 0.1f, 0.3f, 1.0f};
  //GLfloat light0_diffuse[] =  {.6f, .6f, 1.0f, 1.0f};
  //GLfloat light0_position[] = {200.0f, 200.0f, -4.0f, 1.0f};
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  //glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
  //glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
  //glLightfv(GL_LIGHT0, GL_POSITION, light0_position);

  /*          Enable z-buferring          */
  glEnable(GL_DEPTH_TEST);

  //objects = glGenLists(NOBJECTS); printf("objects = %d\n",objects);

  /*         Here's the GLUI code         */
  //  GLUI *glui = GLUI_Master.create_glui( "Control", 0, 600, 50 ); // name, flags, x, and y
  glui = GLUI_Master.create_glui( "Control", 0, 600, 50 ); // name, flags, x, and y

  new GLUI_StaticText( glui, "MDSPASS ver.2.0" );
  new GLUI_Separator( glui );

  GLUI_Panel *panel000 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  checkbox_pbcx  = new GLUI_Checkbox( panel000, "PBC x", &cell.pbcx);
  new GLUI_Column( panel000, false );
  checkbox_pbcy  = new GLUI_Checkbox( panel000, "PBC y", &cell.pbcy);
  new GLUI_Column( panel000, false );
  checkbox_pbcz  = new GLUI_Checkbox( panel000, "PBC z", &cell.pbcz);
  new GLUI_Column( panel000, false );
  GLUI_Listbox *potlist = new GLUI_Listbox( panel000, "Potential:", &ipottype,0,potential_set);
  for (int i=0; i<MAXPOTTYPE; i++) { potlist->add_item(i, potstring_list[i]); }
  GLUI_Panel *panel001 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  //setdexdt_btn = new GLUI_Button( panel001, "Set dex/dt", SETDEXDT_ID, pointer_cb );
  //new GLUI_Column( panel001, false );
  setparam_btn = new GLUI_Button( panel001, "Set param", SETPARAM_ID, pointer_cb );
  new GLUI_Column( panel001, false );
  mdswitch_btn = new GLUI_Button( panel001, "MD on/off", MDSWITCH_ID, pointer_cb );
  new GLUI_Column( panel001, false );
  GLUI_EditText *spinner_temp_set = new GLUI_EditText( panel001, "Temp set:", &temp_set );
  spinner_temp_set->set_float_limits( 0.0f, 1000.0 );
  spinner_temp_set->set_alignment(GLUI_ALIGN_RIGHT);
  /*
  GLUI_Panel *panel002 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  new GLUI_Button(panel002, "Strs chk", STRSCHK_ID, pointer_cb);
  new GLUI_Column(panel002, false );
  new GLUI_EditText(panel002, "de", &eps_strschk);
  */
  strs_btn = new GLUI_Button(panel001, "Stress", STRS_ID, pointer_cb);

  GLUI_Rollout *panel003 = new GLUI_Rollout(glui, "QC settings", false);
  GLUI_Panel *panel0031 = new GLUI_Panel(panel003, "", GLUI_PANEL_NONE );
  checkbox_QC  = new GLUI_Checkbox( panel0031, "QC", &atom.QC);
  new GLUI_Column(panel0031, false );
  checkbox_show_only_elem  = new GLUI_Checkbox( panel0031, "Show only QC element", &show_only_elem);
  GLUI_Panel *panel0032 = new GLUI_Panel(panel003, "", GLUI_PANEL_NONE );
  edit_elem_btn = new GLUI_Button( panel0032, "Edit elem", EDIT_ELEM_ID, pointer_cb );
  new GLUI_Column( panel0032, false );
  edit_elem_xz_btn = new GLUI_Button( panel0032, "Edit elem xz", EDIT_ELEM_XZ_ID, pointer_cb );
  GLUI_Panel *panel0033 = new GLUI_Panel(panel003, "", GLUI_PANEL_NONE );
  open_file_qcelement_btn = new GLUI_Button(panel0033, "Read qcelement", OPEN_FILE_QCELEMENT_ID, pointer_cb );
  new GLUI_Column( panel0033, false );
  writeqcelement_btn = new GLUI_Button( panel0033, "Write qcelement", WRITEQCELEMENT_ID, pointer_cb );

  //  edittext = new GLUI_EditText( glui, "Text:", text, 3, control_cb );
  GLUI_Panel *panel005 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  GLUI_Panel *ensemble_panel = new GLUI_Panel( panel005, "Ensemble Type" );
  radio = new GLUI_RadioGroup( ensemble_panel,&ensemble,CB_ENSEMBLE,control_cb );
  new GLUI_RadioButton( radio, "NVE" );
  new GLUI_RadioButton( radio, "NVT" );
  new GLUI_RadioButton( radio, "Relaxation" );
  //  new GLUI_RadioButton( radio, "diamond" );

  new GLUI_Column( panel005, false );
  //  new GLUI_Column( panel005, false );
  checkbox_Trans  = new GLUI_Checkbox( panel005, "No translation", &notrans);

  GLUI_Rollout *panel00 = new GLUI_Rollout(glui, "Instability analysis", false);
  //  GLUI_Panel *panel00 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  checkbox_evec = new GLUI_Checkbox( panel00, "Evector", &ievec);
  //  new GLUI_Column( panel00, false);
  spinner_instcenter_num  = new GLUI_Spinner( panel00, "Center atom (inst)", &atom.instcenter, 2, control_cb);
  spinner_instcenter_num->set_int_limits( 1, NMAX );
  spinner_instcenter_num->set_speed( 0.01 );
  new GLUI_Column( panel00, false );
  spinner_evec_num = new GLUI_Spinner( panel00, "Mode", &ievec_num, 2, control_cb );
  spinner_evec_num->set_int_limits( 1, 20 );  //  spinner_evec_num->set_speed( 0.01 );
  //  new GLUI_Column( panel00, false);
  spinner_evec_len = new GLUI_Spinner( panel00, "Length", &evec_len, 2, control_cb );
  inst_btn = new GLUI_Button( panel00, "Inst analysis", INST_ID, pointer_cb );

  GLUI_Panel *panel1 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  GLUI_Rotation *view_rot = new GLUI_Rotation( panel1, "Rotation", rotate);
  //  GLUI_Rotation *view_rot = glui->add_rotation( "Rotation", rotate);
  float array[16] = {1.0, 0.0, 0.0, 0.0, 
		     0.0, 0.0,-1.0, 0.0, 
		     0.0, 1.0, 0.0, 0.0, 
		     0.0, 0.0, 0.0, 1.0};
  view_rot->set_float_array_val(array);
  new GLUI_Column( panel1, false );
  GLUI_Translation *trans_xy = new GLUI_Translation( panel1, "Objects XY", GLUI_TRANSLATION_XY, obj_pos );
  trans_xy->set_speed(0.005);
  new GLUI_Column( panel1, false );
  GLUI_Translation *trans_z =  new GLUI_Translation( panel1, "Objects Z", GLUI_TRANSLATION_Z, &scl );
  trans_z->set_speed(0.005);
  new GLUI_Column( panel1, false );
  GLUI_Button *capture_cutton = new GLUI_Button(panel1, "Capture", CAPTURE_ID, pointer_cb);
  GLUI_EditText *capture_counter = new GLUI_EditText(panel1, "", &capture_count);

  GLUI_Rollout *panel11 = new GLUI_Rollout(glui, "Status", true);
  //GLUI_Panel *panel110 = new GLUI_Panel(panel11, "", GLUI_PANEL_NONE);
  //panel110->set_alignment(GLUI_ALIGN_RIGHT);
  //GLUI_EditText *counter_edittext = new GLUI_EditText(panel110, "Step", &istep);
  //counter_edittext->disable();
  GLUI_Panel *panel111 = new GLUI_Panel(panel11, "", GLUI_PANEL_NONE);
  panel111->set_alignment(GLUI_ALIGN_RIGHT);
  GLUI_EditText *step_monitor = new GLUI_EditText(panel111, "Step", &istep);
  step_monitor->set_alignment(GLUI_ALIGN_RIGHT);
  GLUI_EditText *epot_monitor = new GLUI_EditText(panel111, "E_pot(eV/atm)", &epotatom);
  epot_monitor->set_alignment(GLUI_ALIGN_RIGHT);
  epot_monitor->set_w(150);
  GLUI_EditText *cnt_text1 = new GLUI_EditText(panel111, "CNTprs(nN/atm)", &cnt_pressure_ftot);
  cnt_text1->set_alignment(GLUI_ALIGN_RIGHT);
  cnt_text1->set_w(160);
  GLUI_EditText *temp_monitor = new GLUI_EditText(panel111, "Temp(K)", &tempc);
  temp_monitor->set_alignment(GLUI_ALIGN_RIGHT);
  GLUI_EditText *fmax_monitor = new GLUI_EditText(panel111, "Fmax(ev/A)", &f_max);
  fmax_monitor->set_alignment(GLUI_ALIGN_RIGHT);
  new GLUI_Column( panel11, false );
  GLUI_Panel *panel112 = new GLUI_Panel(panel11, "", GLUI_PANEL_NONE);
  panel112->set_alignment(GLUI_ALIGN_RIGHT);
  status_lx = new GLUI_EditText(panel112, "Cell (A)", &cellx,0,pointer_cb); 
  status_ly = new GLUI_EditText(panel112, "        ", &celly,0,pointer_cb);
  status_lz = new GLUI_EditText(panel112, "        ", &cellz,0,pointer_cb);
  status_dt = new GLUI_EditText(panel112, "dt (fs)", &dtm,0,pointer_cb);
  

  GLUI_Rollout *panel2 = new GLUI_Rollout( glui, "File control and config creation", false );
  GLUI_Panel *panel21 = new GLUI_Panel(panel2, "", GLUI_PANEL_NONE);
  open_file_btn = new GLUI_Button( panel21, "Read Config", OPEN_FILE_ID, pointer_cb );
  new GLUI_Column( panel21, false );
  writeconfig_btn = new GLUI_Button( panel21, "Write Config", WRITECONFIG_ID, pointer_cb );
  new GLUI_Column( panel21, false );
  createconfig_btn = new GLUI_Button( panel21, "Create Config", CREATECONFIG_ID, pointer_cb );

  GLUI_Panel *panel3 = new GLUI_Panel( glui, "", GLUI_PANEL_NONE );
  reset_btn = new GLUI_Button( panel3, "Reset", RESET_ID, pointer_cb );
  new GLUI_Column( panel3, false );
  new GLUI_Button( panel3, "Quit", 0, (GLUI_Update_CB)exit );
  glui->set_main_gfx_window( main_window );

  //GLUI_Master.set_glutIdleFunc( NULL );
  GLUI_Master.set_glutIdleFunc( myGlutIdle );

  //  writedata_initialize();

  // Loop

  glutMainLoop();



  //  fouttraj.close();
  //  fout.close();

  return EXIT_SUCCESS;
}

