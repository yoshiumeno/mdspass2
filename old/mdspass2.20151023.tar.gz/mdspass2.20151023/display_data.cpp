#include <stdio.h>
#include <math.h>
#include "myheader.h"

void show_e_force_all()
{
  printf("Position (A)\n");
  for (int i=1; i<=atom.natom; i++) {
    printf("%4d [%2s] %25.15e %25.15e %25.15e\n", 
	   i,atom.asp[i],atom.rx[i]/ang,atom.ry[i]/ang,atom.rz[i]/ang); }
  printf("\n");
  printf("Force (eV/A)\n");
  for (int i=1; i<=atom.natom; i++) {
    printf("%4d [%2s] %25.15e %25.15e %25.15e\n",
	   i,atom.asp[i],atom.fx[i]/ev*ang,atom.fy[i]/ev*ang,atom.fz[i]/ev*ang); }
  printf("\n");
  printf("Energy (eV)\n");
  for (int i=1; i<=atom.natom; i++) {
    printf("%4d [%2s] %25.15e\n",
	   i,atom.asp[i],atom.epot[i]/ev); }
}
