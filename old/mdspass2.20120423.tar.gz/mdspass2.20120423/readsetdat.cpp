#include <string>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

extern int radius, show_cnt_wall, show_cnt_wallv, show_cnt_wall_num;
extern int show_axis, show_cell;
extern int draw_bond;
extern bool mode_cnt_corrugation;
extern float bondlength;

void get_first_arg(std::string &line, std::string &arg1);

double find_double(char* fname, char* tag)
{
  //char* fname = "setdat";
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  double arg;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      arg = (double)atof(arg2.c_str());
    }
  }
  fin.close();
  return arg;
}

int find_int(char* fname, char* tag)
{
  //char* fname = "setdat";
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  int arg;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      arg = atoi(arg2.c_str());
    }
  }
  fin.close();
  return arg;
}

bool find_bool(char* fname, char* tag)
{
  //char* fname = "setdat";
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  bool arg;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      if (strcmp(arg2.c_str(), "Yes")==0) {
	arg = true;
      } else if (strcmp(arg2.c_str(), "yes")==0) {
	arg = true;
      } else if (strcmp(arg2.c_str(), "YES")==0) {
	arg = true;
      } else {
	arg = false;
      }
    }
  }
  fin.close();
  return arg;
}

void readsetdat(char* fname)
{
  printf("### Read setdat    ###\n",dt);
  dt = find_double(fname, "dt");  printf("dt = %e\n",dt);
  book.frc = find_double(fname, "frc");  printf("frc = %e\n",book.frc); book.frc2 = book.frc*book.frc;
  book.nbk = find_int(fname, "nbk");  printf("nbk = %d\n",book.nbk);

  cell.pbcx = find_bool(fname, "pbcx"); printf("pbcx = %d\n", cell.pbcx);
  cell.pbcy = find_bool(fname, "pbcy"); printf("pbcy = %d\n", cell.pbcy);
  cell.pbcz = find_bool(fname, "pbcz"); printf("pbcz = %d\n", cell.pbcz);

  radius = find_int(fname, "radius");
  draw_bond = find_bool(fname, "draw_bond");
  bondlength = (float)find_double(fname, "bondlength");
  show_cell = find_bool(fname, "show_cell");
  show_axis = find_bool(fname, "show_axis");
  show_cnt_wall = find_bool(fname, "show_cnt_wall");
  show_cnt_wallv = find_bool(fname, "show_cnt_wallv");
  show_cnt_wall_num = find_int(fname, "show_cnt_wall_num");
  mode_cnt_corrugation = find_bool(fname, "cnt_corrugation");
  printf("### Read setdat end ###\n",dt);
  /*
  char string[80];
  FILE *fp = fopen("setdat","r");
  fgets(string, 80, fp);
  printf("%s\n",string);
  */
}
