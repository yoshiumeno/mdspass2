#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

//double v(double rmeter);
//double vp(double rmeter);
//void e_force_morse_nobook();
//void e_force_morse();
void potential();
void vscale();
void vscale(double target);
void vscale(int i, double target);
void writedata();
void stretch(double x, double y, double z);
void loading();
extern float ex,dexdt;
extern float ey,deydt;
extern float ez,dezdt;
//void writedata(FILE *fp);

/*
  double det3(double mat3[][4])
  {
  return mat3[1][1]*mat3[2][2]*mat3[3][3] + mat3[2][1]*mat3[3][2]*mat3[1][3] 
  + mat3[3][1]*mat3[1][2]*mat3[2][3] 
  - mat3[3][1]*mat3[2][2]*mat3[1][3] - mat3[3][2]*mat3[2][3]*mat3[1][1]
  - mat3[3][3]*mat3[2][1]*mat3[1][2];
  }
*/
void inverse(double mat[][4], double imat[][4])
{
  double detm;
  detm = mat[1][1]*mat[2][2]*mat[3][3] + mat[2][1]*mat[3][2]*mat[1][3] 
    + mat[3][1]*mat[1][2]*mat[2][3] - mat[3][1]*mat[2][2]*mat[1][3]
    - mat[3][2]*mat[2][3]*mat[1][1] - mat[3][3]*mat[2][1]*mat[1][2];
  imat[1][1] =  (mat[2][2]*mat[3][3]-mat[3][2]*mat[2][3]) / detm;
  imat[1][2] = -(mat[1][2]*mat[3][3]-mat[3][2]*mat[1][3]) / detm;
  imat[1][3] =  (mat[1][2]*mat[2][3]-mat[2][2]*mat[1][3]) / detm;
  imat[2][1] = -(mat[2][1]*mat[3][3]-mat[3][1]*mat[2][3]) / detm;
  imat[2][2] =  (mat[1][1]*mat[3][3]-mat[3][1]*mat[1][3]) / detm;
  imat[2][3] = -(mat[1][1]*mat[2][3]-mat[2][1]*mat[1][3]) / detm;
  imat[3][1] =  (mat[2][1]*mat[3][2]-mat[3][1]*mat[2][2]) / detm;
  imat[3][2] = -(mat[1][1]*mat[3][2]-mat[3][1]*mat[1][2]) / detm;
  imat[3][3] =  (mat[1][1]*mat[2][2]-mat[2][1]*mat[1][2]) / detm;
}
void mk_helmat(int iel, double rx[], double ry[], double rz[], double mat[][4])
{
  int ix, iy, iz, ix0, iy0, iz0;

  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }

  if (atom.elem_v_rep[iel][2] >= 4) { ix = 1; } else { ix = 0; }
  if ((atom.elem_v_rep[iel][2] % 4 == 2)||(atom.elem_v_rep[iel][2] % 4 == 3)) { iy = 1; } else { iy = 0; }
  if (atom.elem_v_rep[iel][2] % 2 == 1) { iz = 1; } else { iz = 0; }
  ix = ix-ix0; iy = iy-iy0; iz = iz-iz0;
  mat[1][1] = rx[atom.elem_v[iel][2]] - rx[atom.elem_v[iel][1]]
    + cell.hmat[1][1]*ix + cell.hmat[1][2]*iy + cell.hmat[1][3]*iz;
  mat[2][1] = ry[atom.elem_v[iel][2]] - ry[atom.elem_v[iel][1]]
    + cell.hmat[2][1]*ix + cell.hmat[2][2]*iy + cell.hmat[2][3]*iz;
  mat[3][1] = rz[atom.elem_v[iel][2]] - rz[atom.elem_v[iel][1]]
    + cell.hmat[3][1]*ix + cell.hmat[3][2]*iy + cell.hmat[3][3]*iz;

  if (atom.elem_v_rep[iel][3] >= 4) { ix = 1; } else { ix = 0; }
  if ((atom.elem_v_rep[iel][3] % 4 == 2)||(atom.elem_v_rep[iel][3] % 4 == 3)) { iy = 1; } else { iy = 0; }
  if (atom.elem_v_rep[iel][3] % 2 == 1) { iz = 1; } else { iz = 0; }
  ix = ix-ix0; iy = iy-iy0; iz = iz-iz0;
  mat[1][2] = rx[atom.elem_v[iel][3]] - rx[atom.elem_v[iel][1]]
    + cell.hmat[1][1]*ix + cell.hmat[1][2]*iy + cell.hmat[1][3]*iz;
  mat[2][2] = ry[atom.elem_v[iel][3]] - ry[atom.elem_v[iel][1]]
    + cell.hmat[2][1]*ix + cell.hmat[2][2]*iy + cell.hmat[2][3]*iz;
  mat[3][2] = rz[atom.elem_v[iel][3]] - rz[atom.elem_v[iel][1]]
    + cell.hmat[3][1]*ix + cell.hmat[3][2]*iy + cell.hmat[3][3]*iz;

  if (atom.elem_v_rep[iel][4] >= 4) { ix = 1; } else { ix = 0; }
  if ((atom.elem_v_rep[iel][4] % 4 == 2)||(atom.elem_v_rep[iel][4] % 4 == 3)) { iy = 1; } else { iy = 0; }
  if (atom.elem_v_rep[iel][4] % 2 == 1) { iz = 1; } else { iz = 0; }
  ix = ix-ix0; iy = iy-iy0; iz = iz-iz0;
  mat[1][3] = rx[atom.elem_v[iel][4]] - rx[atom.elem_v[iel][1]]
    + cell.hmat[1][1]*ix + cell.hmat[1][2]*iy + cell.hmat[1][3]*iz;
  mat[2][3] = ry[atom.elem_v[iel][4]] - ry[atom.elem_v[iel][1]]
    + cell.hmat[2][1]*ix + cell.hmat[2][2]*iy + cell.hmat[2][3]*iz;
  mat[3][3] = rz[atom.elem_v[iel][4]] - rz[atom.elem_v[iel][1]]
    + cell.hmat[3][1]*ix + cell.hmat[3][2]*iy + cell.hmat[3][3]*iz;
}
/*
void mk_qxyz(int i, int iel, double rx[], double ry[], double rz[], double hinelmat_p[][4], 
	     double &qx, double &qy, double &qz)
{
  double xx, yy, zz;
  xx = rx[i] - rx[atom.elem_v[iel][1]];
  yy = ry[i] - ry[atom.elem_v[iel][1]];
  zz = rz[i] - rz[atom.elem_v[iel][1]];
  qx = hinelmat_p[1][1]*xx + hinelmat_p[1][2]*yy + hinelmat_p[1][3]*zz;
  qy = hinelmat_p[2][1]*xx + hinelmat_p[2][2]*yy + hinelmat_p[2][3]*zz;
  qz = hinelmat_p[3][1]*xx + hinelmat_p[3][2]*yy + hinelmat_p[3][3]*zz;
}
*/
double q_x(int i, int iel, double rx[], double ry[], double rz[], double hinelmat[][4])
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  double xx = rx[i] - x0; double yy = ry[i] - y0; double zz = rz[i] - z0;
  return hinelmat[1][1]*xx + hinelmat[1][2]*yy + hinelmat[1][3]*zz;
}
double q_y(int i, int iel, double rx[], double ry[], double rz[], double hinelmat[][4])
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  double xx = rx[i] - x0; double yy = ry[i] - y0; double zz = rz[i] - z0;
  return hinelmat[2][1]*xx + hinelmat[2][2]*yy + hinelmat[2][3]*zz;
}
double q_z(int i, int iel, double rx[], double ry[], double rz[], double hinelmat[][4])
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  double xx = rx[i] - x0; double yy = ry[i] - y0; double zz = rz[i] - z0;
  return hinelmat[3][1]*xx + hinelmat[3][2]*yy + hinelmat[3][3]*zz;
}
/*
void mk_rxyz(int i, int iel, double rx[], double ry[], double rz[], double helmat[][4], 
	     double qx, double qy, double qz)
{
  rx[i] = rx[atom.elem_v[iel][1]] + helmat[1][1]*qx + helmat[1][2]*qy + helmat[1][3]*qz;
  ry[i] = ry[atom.elem_v[iel][1]] + helmat[2][1]*qx + helmat[2][2]*qy + helmat[2][3]*qz;
  rz[i] = rz[atom.elem_v[iel][1]] + helmat[3][1]*qx + helmat[3][2]*qy + helmat[3][3]*qz;
}
*/
double r_x(int i, int iel, double rx[], double ry[], double rz[], double helmat[][4], 
	   double qx, double qy, double qz)
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  return x0 + helmat[1][1]*qx + helmat[1][2]*qy + helmat[1][3]*qz;
  //  return rx[ii] + helmat[1][1]*qx + helmat[1][2]*qy + helmat[1][3]*qz;
}
double r_y(int i, int iel, double rx[], double ry[], double rz[], double helmat[][4], 
	   double qx, double qy, double qz)
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  return y0 + helmat[2][1]*qx + helmat[2][2]*qy + helmat[2][3]*qz;
  //  return ry[ii] + helmat[2][1]*qx + helmat[2][2]*qy + helmat[2][3]*qz;
}
double r_z(int i, int iel, double rx[], double ry[], double rz[], double helmat[][4], 
	   double qx, double qy, double qz)
{
  double x0, y0, z0; int ix0, iy0, iz0;
  x0=rx[atom.elem_v[iel][1]]; y0=ry[atom.elem_v[iel][1]]; z0=rz[atom.elem_v[iel][1]];
  if (atom.elem_v_rep[iel][1] >= 4) { ix0 = 1; } else { ix0 = 0; }
  if ((atom.elem_v_rep[iel][1] % 4 == 2)||(atom.elem_v_rep[iel][1] % 4 == 3)) { iy0 = 1; } else { iy0 = 0; }
  if (atom.elem_v_rep[iel][1] % 2 == 1) { iz0 = 1; } else { iz0 = 0; }
  x0=x0+cell.hmat[1][1]*ix0+cell.hmat[1][2]*iy0+cell.hmat[1][3]*iz0;
  y0=y0+cell.hmat[2][1]*ix0+cell.hmat[2][2]*iy0+cell.hmat[2][3]*iz0;
  z0=z0+cell.hmat[3][1]*ix0+cell.hmat[3][2]*iy0+cell.hmat[3][3]*iz0;
  return z0 + helmat[3][1]*qx + helmat[3][2]*qy + helmat[3][3]*qz;
  //  return rz[ii] + helmat[3][1]*qx + helmat[3][2]*qy + helmat[3][3]*qz;
}

void md()
{
  double rr, drx, dry, drz;
  double helmat_p[4][4], hinelmat_p[4][4], helmat[4][4];
  double qx, qy, qz, xx, yy, zz;

  // Velet[1]
  for (int i=1; i<=atom.natom; i++)
    {
      atom.rx_p[i] = atom.rx[i]; atom.ry_p[i] = atom.ry[i]; atom.rz_p[i] = atom.rz[i]; 
      if ((atom.QC==0)||(atom.repatom[i] == 1)) {
	atom.rx[i] = atom.rx[i] + dt * atom.vx[i] + (dt*dt/2.0) * atom.fx[i] / atom.wm[i];
	atom.ry[i] = atom.ry[i] + dt * atom.vy[i] + (dt*dt/2.0) * atom.fy[i] / atom.wm[i];
	atom.rz[i] = atom.rz[i] + dt * atom.vz[i] + (dt*dt/2.0) * atom.fz[i] / atom.wm[i];
	atom.vx[i] = atom.vx[i] + dt/2.0 * atom.fx[i] / atom.wm[i];
	atom.vy[i] = atom.vy[i] + dt/2.0 * atom.fy[i] / atom.wm[i];
	atom.vz[i] = atom.vz[i] + dt/2.0 * atom.fz[i] / atom.wm[i];
	if (atom.mfx[i] == true) { atom.rx[i] = atom.rx_p[i]; atom.vx[i] = 0.0; }
	if (atom.mfy[i] == true) { atom.ry[i] = atom.ry_p[i]; atom.vy[i] = 0.0; }
	if (atom.mfz[i] == true) { atom.rz[i] = atom.rz_p[i]; atom.vz[i] = 0.0; }
      }
    }
  if (atom.QC) {
  for (int iel=1; iel<=atom.nelem; iel++)
    {
      mk_helmat(iel, atom.rx_p, atom.ry_p, atom.rz_p, helmat_p);
      mk_helmat(iel, atom.rx, atom.ry, atom.rz, helmat);
      inverse(helmat_p, hinelmat_p);
      for (int i=1; i<=atom.natom; i++)
	{
	  if ((atom.repatom[i] == 0)&&(atom.elem_id[i] == iel)) {
	    //	    mk_qxy(i, iel, atom.rx_p, atom.ry_p, hinelmat_p, qx, qy);
	    qx = q_x(i, iel, atom.rx_p, atom.ry_p, atom.rz_p, hinelmat_p);
	    qy = q_y(i, iel, atom.rx_p, atom.ry_p, atom.rz_p, hinelmat_p);
	    qz = q_z(i, iel, atom.rx_p, atom.ry_p, atom.rz_p, hinelmat_p);
	    //	    mk_rxy(i, iel, atom.rx, atom.ry, helmat, qx, qy);
	    atom.rx[i] = r_x(i, iel, atom.rx, atom.ry, atom.rz, helmat, qx, qy, qz);
	    atom.ry[i] = r_y(i, iel, atom.rx, atom.ry, atom.rz, helmat, qx, qy, qz);
	    atom.rz[i] = r_z(i, iel, atom.rx, atom.ry, atom.rz, helmat, qx, qy, qz);
	    atom.vx[i] = ( atom.rx[i]-atom.rx_p[i] ) / dt;
	    atom.vy[i] = ( atom.ry[i]-atom.ry_p[i] ) / dt;
	    atom.vz[i] = ( atom.rz[i]-atom.rz_p[i] ) / dt;
	  }
	}
    }
  }
  // Force and energy calculation
  potential(); if (mdmotion == 0) { return; }
  // External load
  loading();
  // Stretch
  ex=ex+dexdt*dt*1e12; double strx=cell.hmat_org[1][1]*(1.0+ex)/cell.hmat[1][1];
  ey=ey+deydt*dt*1e12; double stry=cell.hmat_org[2][2]*(1.0+ey)/cell.hmat[2][2];
  ez=ez+dezdt*dt*1e12; double strz=cell.hmat_org[3][3]*(1.0+ez)/cell.hmat[3][3];
  stretch(strx,stry,strz);

  // Velet[2]
  for (int i=1; i<=atom.natom; i++)
    {
      if ((atom.QC==0)||(atom.repatom[i] == 1)) {
	atom.vx[i] = atom.vx[i] + dt/2.0 * atom.fx[i] / atom.wm[i];
	atom.vy[i] = atom.vy[i] + dt/2.0 * atom.fy[i] / atom.wm[i];
	atom.vz[i] = atom.vz[i] + dt/2.0 * atom.fz[i] / atom.wm[i];
      }
    }

  // Potential and kinetic energies
  atom.epotsum=0.0; atom.ekinsum=0.0;
  for (int i=1; i<=atom.natom; i++)
    {
      atom.epotsum=atom.epotsum+atom.epot[i];
      atom.ekinsum=atom.ekinsum+atom.wm[i]/2.0*(atom.vx[i]*atom.vx[i]+atom.vy[i]*atom.vy[i]+atom.vz[i]*atom.vz[i]);
    }

  // Velocity control
  if (ensemble == 1) { // Velocity scaling NVT
    vscale();
  }

  if (ensemble == 2) { // GLOC relaxation
    double dp = 0.0;
    if (atom.QC==0) {
      for (int i=1; i<=atom.natom; i++) {
	dp = dp + atom.vx[i]*atom.fx[i] + atom.vy[i]*atom.fy[i] + atom.vz[i]*atom.fz[i];
      }
      if (dp < 0.0) { vscale(0.0); }
    } else {
      for (int i=1; i<=atom.natom; i++) {
	if (atom.repatom[i]) {
	  dp = dp + atom.vx[i]*atom.fx[i] + atom.vy[i]*atom.fy[i] + atom.vz[i]*atom.fz[i];
	}
	// if (dp < 0.0) { vscale(i, 0.0); }
      }
      if (dp < 0.0) { vscale(0.0); }
	
    }

  }

  if (notrans) {
    double transx = 0.0; double transy = 0.0; double transz = 0.0;
    for (int i=1; i<=atom.natom; i++) {
      transx = transx + atom.vx[i]; transy = transy + atom.vy[i]; transz = transz + atom.vz[i];
    }
    transx = transx / atom.natom; transy = transy / atom.natom; transz = transz / atom.natom;
    for (int i=1; i<=atom.natom; i++) {
      atom.vx[i] = atom.vx[i] - transx; atom.vy[i] = atom.vy[i] - transy; atom.vz[i] = atom.vz[i] - transz;
    }
  }

  // For temperature monitoring
  if (atom.QC==0) {
    tempc = atom.Enkin()*2.0/3.0/(double)atom.natom/1.380662e-23;
  } else {
    tempc = atom.Enkin()*2.0/3.0/(double)atom.nrepatom/1.380662e-23;
  }

  // For output in "Status" area
  cellx=cell.hmat[1][1]/ang;celly=cell.hmat[2][2]/ang;cellz=cell.hmat[3][3]/ang;
  f_max=atom.Fmax()/ev*ang;

}
  
