#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include "myheader.h"
void tersoff_alloc();
void tersoff_setparam(int mparam);
double fcut(double r, double rr, double ss);
double fcutd(double r, double rr, double ss);
double v(double rmeter);
double vp(double rmeter);

void e_force_tersoff()
{
  double rr, rr2, drx, dry, drz, vp0, v0;
  int j, ix, iy, iz;
  double rcut = 13.0e0; double rcut2 = rcut * rcut;

  double pi = M_PI, eps = 1.0e-20, ev2j = 1.6021892e-19, j2ev = 1.0/ev2j;
  int mode = 1; //1:38-14(B,C),2:39-8(Multi),1:Date's type
  int mparam = 0; //!0:Si(B), 1:Si(C) [see PRB 38 p.9902]
  //4:Date's potential(B),5:Yasukawa,6:Date's Potential(read from file)

  //if (strcmp(atom.potential_arg,"B")==0) mparam=0;
  //if (strcmp(atom.potential_arg,"C")==0) mparam=1;
  //if (strcmp(atom.potential_arg,"B2")==0) mparam=2;
  //if (strcmp(atom.potential_arg,"Sn")==0) mparam=3;

  if (tersoff.initialize) {
    std::cout<<"Initialize of the Tersoff potential..";
    tersoff_alloc();
    if (book.algo != 2) { printf("Error in Tersoff: Bookkeep algo is not 2 (double)\n"); goto OUT; }
    if (atom.natom > 3000) { printf("ERROR: Please use TersoffNM instead.\n"); goto OUT; }
    tersoff_setparam(mparam);
    tersoff.initialize = false;
  }
 OUT:
  int istat = 1;
  double rc = tersoff.terss;
  double rc2 = rc*rc;

  int kns, kn, kns0;
  double rix, riy, riz, rjx, rjy, rjz, fij, rkx, rky, rkz;

  //   Virial term reset
  //    virx=0.0d0; viry=0.0d0; virz=0.0d0
  //    dmat=0.0d0
  //    satom=0.0d0               ! Atomic stress

  //========================================================
  //   Loop for b and z
  for (int i=1; i<=atom.natom; i++) {
    for (int j=1; j<=atom.natom; j++) {
      tersoff.zmat[i][j] = 0; tersoff.b[i][j] = 0; } }
  kns = 0;
  for (int i=1; i<=atom.natom; i++) {
    rix = atom.rx[i]; riy = atom.ry[i]; riz = atom.rz[i];
    if (book.alistnum[i]>0) {
      for (int k0=1; k0<=book.alistnum[i]; k0++) {
	int j = book.alist[i][k0][0];
	int ix = book.alist[i][k0][1]; int iy = book.alist[i][k0][2]; int iz = book.alist[i][k0][3];
	double rij2 = atom.Dist2(i,j,ix,iy,iz);
	if ((rij2 < rc2)&&(rij2 > eps)) {
	  double rij = sqrt(rr2);
	  rjx = atom.rx[i] - atom.Dx(i,j,ix,iy,iz);
	  rjy = atom.ry[i] - atom.Dy(i,j,ix,iy,iz);
	  rjz = atom.rz[i] - atom.Dz(i,j,ix,iy,iz);
	  fij = fcut(rij,tersoff.terrr,tersoff.terss);
	  if (fij < eps) { continue; }
	  //--------------calc bij---------------------
	  for (int k1=1; k1<=book.alistnum[i]; k1++) {
	    int k = book.alist[i][k1][0];
	    ix = book.alist[i][k1][1]; iy = book.alist[i][k1][2]; iz = book.alist[i][k1][3];
	    rkx = atom.rx[i] - atom.Dx(i,k,ix,iy,iz);
	    rky = atom.ry[i] - atom.Dy(i,k,ix,iy,iz);
	    rkz = atom.rz[i] - atom.Dz(i,k,ix,iy,iz);
	    double rik2 = atom.Dist2(i,k,ix,iy,iz);
	    if (rik2 < eps) { continue; }
	    double rik = sqrt(rik2);
	    
	    
	  }
	}
      } 
    }
  }


  for (int i=1; i<=atom.natom; i++) {
    atom.fx[i] = 0.0; atom.fy[i] = 0.0; atom.fz[i] = 0.0;  atom.epot[i] = 0.0;
  }


  for (int i=1; i<=atom.natom; i++) {
    if ((atom.QC==0)||(atom.repatom[i]==1)) {
      if (book.alistnum[i]>0) {
	for (int k=1; k<=book.alistnum[i]; k++) {
	  j  = book.alist[i][k][0];
	  ix = book.alist[i][k][1]; iy = book.alist[i][k][2]; iz = book.alist[i][k][3];
	  rr2 = atom.Dist2(i,j,ix,iy,iz);
	  //	if ((rr2 < rcut2)&&(rr2>1.0e-30)) {
	  if (rr2 < rcut2) {
	    rr = sqrt(rr2);
	    drx = atom.Dx(i,j,ix,iy,iz); dry = atom.Dy(i,j,ix,iy,iz); drz = atom.Dz(i,j,ix,iy,iz);
	    atom.fx[i] = atom.fx[i]+vp(rr)/rr*drx;
	    atom.fy[i] = atom.fy[i]+vp(rr)/rr*dry;
	    atom.fz[i] = atom.fz[i]+vp(rr)/rr*drz;
	    atom.epot[i]=atom.epot[i]+v(rr)/2.0;
	  }
	}
      }
    }
    //    printf("SLOW %d %20.15e %20.15e\n",i,atom.fx[i],rr2);
  }
  //  if (istep==0) {exit(0);}
}


void tersoff_alloc()
{
  tersoff.zmat = new double*[atom.natom+1];
  tersoff.b = new double*[atom.natom+1];
  for (int i=0; i<atom.natom+1; i++) {
    tersoff.zmat[i] = new double[atom.natom+1];
    tersoff.b[i] = new double[atom.natom+1]; }
}

void tersoff_setparam(int mparam)
{
  double pi = M_PI, eps = 1.0e-20, ev2j = 1.6021892e-19, j2ev = 1.0/ev2j;
  if (mparam == 0) {     // Si(B) (for surface structure)
    tersoff.terrr=2.80e-10;
    tersoff.terss=3.20e-10;
    tersoff.teraa=3.2647e3*ev2j;
    tersoff.terbb=9.5373e1*ev2j;
    tersoff.terlambda=3.2394e10;
    tersoff.termu=1.3258e10;
    tersoff.terbeta=3.3675e-1;
    tersoff.tern=2.2956e1;
    tersoff.term=3;
    tersoff.terc=4.8381e0;
    tersoff.terd=2.0417e0;
    tersoff.terh=0.0e0;
    tersoff.terw=1.0e0;
  } else if (mparam == 1) {  // Si(C) (for elastic property)
    tersoff.terrr=2.70e-10;
    tersoff.terss=3.00e-10;
    tersoff.teraa=1.8308e3*ev2j;
    tersoff.terbb=4.7118e2*ev2j;
    tersoff.terlambda=2.4799e10;
    tersoff.termu=1.7322e10;
    tersoff.terbeta=1.0999e-6;
    tersoff.tern=7.8734e-1;
    tersoff.term=3;
    tersoff.terc=1.0039e5;
    tersoff.terd=1.6218e1;
    tersoff.terh=-5.9826e-1;
    tersoff.terw=1.0e0;
  } else if (mparam == 2) { // Si(B*) (for phase transformation)
    tersoff.terrr=2.65e-10;
    tersoff.terss=2.85e-10;
    tersoff.teraa=3.2647e3*ev2j;
    tersoff.terbb=9.5373e1*ev2j;
    tersoff.terlambda=3.2394e10;
    tersoff.termu=1.3258e10;
    tersoff.terbeta=3.3675e-1;
    tersoff.tern=2.2956e1;
    tersoff.term=3;
    tersoff.terc=4.8381e0;
    tersoff.terd=2.0417e0;
    tersoff.terh=0.0e0;
    tersoff.terw=1.0e0;
  } else if (mparam == 3) { // Sn (Negami)
    tersoff.terrr=4.15e-10;
    tersoff.terss=4.45e-10;
    tersoff.teraa=1232.0e0*ev2j;
    tersoff.terbb=130.0e0*ev2j;
    tersoff.terlambda=2.277e10;
    tersoff.termu=1.203e10;
    tersoff.tern=0.9907e0;
    tersoff.terbeta=pow(0.1590e0,(1.0/tersoff.tern));
    tersoff.term=1;
    tersoff.terc=312.78e0;
    tersoff.terd=14.489e0;
    tersoff.terh=-0.4604e0;
    tersoff.terw=1.0e0;
  } else {
    printf("Please specify mparam\n");exit(0);
  }
  /*
!     FOR CARBON
!      terrr(2)=1.80e-10
!      terss(2)=2.10e-10
!      teraa(2)=1.3936e3*ev2j
!      terbb(2)=3.467e2*ev2j
!      terlambda(2)=3.4879e10
!      termu(2)=2.2119e10
!      terbeta(2)=1.5724e-7
!      tern(2)=7.2751e-1
!      term(2)=3
!      terc(2)=3.8049e4
!      terd(2)=4.384e0
!      terh(2)=-5.7058e-1
!      terw(2)=1.0e0
  */
  tersoff.terc2=tersoff.terc*tersoff.terc;
  tersoff.terd2=tersoff.terd*tersoff.terd;
  tersoff.termum=pow(tersoff.termu,tersoff.term);
}

double fcut(double r, double rr, double ss)
{
  double pi = M_PI, f;
  if (r < rr) {
    f=1.0;
  } else if (r <= ss) {
    f=0.5+0.5*cos(pi*(r-rr)/(ss-rr));
  } else {
    f=0.0;
  }
  return f;
}
double fcutd(double r, double rr, double ss)
{
  double pi = M_PI, fd;
  if ((r < ss)&&(r > rr)) {
    fd=-pi/2.0*sin(pi*(r-rr)/(ss-rr))/(ss-rr);
  } else {
    fd=0.0;
  }
  return fd;
}
