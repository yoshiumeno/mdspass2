#include <fstream>
#include <iostream>
#include "myheader.h"
/*
void writedata()
{
  std::ofstream foutene( "energy.d", std::ios::out | std::ios::app );
  foutene << istep << " " << atom.epotsum << " " << atom.ekinsum << std::endl;
  
}
*/
//void writedata( FILE *fp )
void writedata()
{
  fprintf(energyfile, "%d %22.17e %22.17e %22.17e\n", istep, atom.epotsum/ev/atom.natom, atom.ekinsum/ev/atom.natom, (atom.epotsum+atom.ekinsum)/ev/atom.natom);
  fflush(energyfile);
  /*
  for (int i=1;i<=atom.natom;i++) {
    printf("%d %22.17e\n",i,atom.epot[i]);
  }
  */
}
/* void writedata_initialize()
{
  std::ofstream foutene( "energy.d", std::ios::trunc );
} */
 //int writedata_initialize(FILE *fp)
void writedata_initialize()
{
  if (energyfile!=NULL) {
    fclose(energyfile);
  }
  energyfile = fopen("energy.d","w");
  //  fseek(fp, 0L, SEEK_SET);
  //fflush(fp);
}
