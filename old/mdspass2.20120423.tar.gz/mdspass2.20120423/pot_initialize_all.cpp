#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"
#include <GL/glui.h>
#include <complex>

using namespace std;

void pot_initialize_all()
{
  bre.initialize = true;
  tersoff.initialize = true;
}
