#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "myheader.h"

void inverse(double mat[][4], double imat[][4]);

void writeconfig(char* fname)
{
  printf ("Write config file = %s\n", fname);
  /*
  std::ofstream foutconfig( "config.end", std::ios::out );
  foutconfig << "ATOM_TYPE" << std::endl;
  foutconfig << "POTENTIAL" << std::endl;
  foutconfig << atom.natom << std::endl;
  */
  FILE *fp;
  double xx, yy, zz;
  double hinmat[4][4];
  //  fp = fopen("config.end", "w");
  fp = fopen(fname, "w");
  fprintf(fp," %s\n","C");
  fprintf(fp," %s %s\n",atom.potential_func,atom.potential_arg);
  fprintf(fp," %d\n",atom.natom);
  fprintf(fp," %e\n",cell.alat);
  xx=cell.hmat[1][1]/cell.alat/1.0e-10; yy=cell.hmat[2][1]/cell.alat/1.0e-10; zz=cell.hmat[3][1]/cell.alat/1.0e-10; 
  fprintf(fp," %20.15e %20.15e %20.15e\n",xx,yy,zz);
  xx=cell.hmat[1][2]/cell.alat/1.0e-10; yy=cell.hmat[2][2]/cell.alat/1.0e-10; zz=cell.hmat[3][2]/cell.alat/1.0e-10; 
  fprintf(fp," %20.15e %20.15e %20.15e\n",xx,yy,zz);
  xx=cell.hmat[1][3]/cell.alat/1.0e-10; yy=cell.hmat[2][3]/cell.alat/1.0e-10; zz=cell.hmat[3][3]/cell.alat/1.0e-10; 
  fprintf(fp," %20.15e %20.15e %20.15e\n",xx,yy,zz);
  fprintf(fp," %s\n","fra");
  inverse(cell.hmat, hinmat);
  for (int i=1; i<=atom.natom; i++) {
    xx = hinmat[1][1]*atom.rx[i] + hinmat[1][2]*atom.ry[i] + hinmat[1][3]*atom.rz[i];
    yy = hinmat[2][1]*atom.rx[i] + hinmat[2][2]*atom.ry[i] + hinmat[2][3]*atom.rz[i];
    zz = hinmat[3][1]*atom.rx[i] + hinmat[3][2]*atom.ry[i] + hinmat[3][3]*atom.rz[i];
    fprintf(fp," %20.15e %20.15e %20.15e\n",xx,yy,zz);
  }

  fclose(fp);
}
