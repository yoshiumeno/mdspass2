#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"
#include <GL/glui.h>

void get_first_arg(std::string &line, std::string &arg1);
void get_first_arg(char* line, char* arg1);
int remove_head_spaces(std::string &line);
int sprit_first_arg(std::string &line, std::string &arg1);
int count_arg_number(std::string line);
void set_atom_weight();
void potential();
void out_of_cell();
void bookkeep();
void pot_initialize_all();
void set_atom_color();

extern GLuint objects;
//extern GLfloat *color[NOBJECTS];
extern GLfloat **color, **color0;
extern int *iatom, *repidx;
extern GLfloat red[], yellow[];
extern float ex;

void readconfig( char* fname )
{
  //  std::ofstream foutene( "energy.d", std::ios::out | std::ios::app );
  
  //  foutene << istep << " " << epotsum << " " << ekinsum << std::endl;
  printf ("Read config file = %s\n", fname);
  strcpy(current_config_name,fname);
  std::ifstream finconfig( fname );
  //std::ifstream finconfig; finconfig.open(fname);
  if (!finconfig) { printf("### File [%s] does not exist! ###\n",fname); return; }
  double xx, yy, zz;
  int ix;
  std::string line;
  std::string arg1, arg2, arg3, arg4, arg5, arg6, arg7;
  char larg1[40], larg2[40], larg3[40], larg4[40];
  char larg5[2], larg6[2], larg7[2];
  bool abs = false;
  char species[3];
  double *rxs, *rys, *rzs, hmats[4][4];
  int natoms;

  natoms = 0;
  if (imerge==1) {
    printf("Read config: Merge mode (Order: Read atoms -> Existing atoms)\n");
    natoms = atom.natom;
    rxs = new double[atom.natom+1]; rys = new double[atom.natom+1]; rzs = new double[atom.natom+1];
    for (int i=1; i<=atom.natom; i++) {
      rxs[i] = atom.rx[i]; rys[i] = atom.ry[i]; rzs[i] = atom.rz[i];
    }
    for (int i=1; i<=3; i++) {
      for (int j=1; j<=3; j++) {
	hmats[i][j] = cell.hmat[i][j];
      } }
  }
  atom.nwall = 0;

  // Deallocate arrays
  if (color) { for (int i=1; i<=atom.natom*3; i++) { if (color[i]) free(color[i]); } free(color); }
  if (color0) { for (int i=1; i<=atom.natom*3; i++) { if (color0[i]) free(color0[i]); } free(color0); }
  if (iatom) { free(iatom); }
  if (repidx) { free(repidx); }
  if (atom.asp) { for (int i=1; i<=atom.natom; i++) { if (atom.asp[i]) free(atom.asp[i]); } free(atom.asp);  }
  if (atom.wm) { delete[] atom.wm; atom.wm = NULL; }
  if (atom.rx) {free(atom.rx);}; if (atom.ry) {free(atom.ry);}; if (atom.rz) {free(atom.rz);}
  if (atom.rx_float) {free(atom.rx_float);}; if (atom.ry_float) {free(atom.ry_float);}; if (atom.rz_float) {free(atom.rz_float);}
  if (atom.rx_org) {free(atom.rx_org);}; if (atom.ry_org) {free(atom.ry_org);}; if (atom.rz_org) {free(atom.rz_org);}
  if (atom.rx_p) {free(atom.rx_p);}; if (atom.ry_p) {free(atom.ry_p);}; if (atom.rz_p) {free(atom.rz_p);}
  if (atom.vx) {free(atom.vx);}; if (atom.vy) {free(atom.vy);}; if (atom.vz) {free(atom.vz);}
  if (atom.fx) {free(atom.fx);}; if (atom.fy) {free(atom.fy);}; if (atom.fz) {free(atom.fz);}
  if (atom.fx_float) {free(atom.fx_float);}; if (atom.fy_float) {free(atom.fy_float);}; if (atom.fz_float) {free(atom.fz_float);}
  if (atom.mfx) {free(atom.mfx);}; if (atom.mfy) {free(atom.mfy);}; if (atom.mfz) {free(atom.mfz);}
  if (atom.epot) {free(atom.epot);}
  if (atom.epot_float) {free(atom.epot_float);}
  if (atom.repatom) {free(atom.repatom);}
  if (atom.elem_id) {free(atom.elem_id);}
  if (atom.evecx) { for (int i=1; i<=atom.natom; i++) { free(atom.evecx[i]); } free(atom.evecx);}
  if (atom.evecy) { for (int i=1; i<=atom.natom; i++) { free(atom.evecy[i]); } free(atom.evecy);}
  if (atom.evecz) { for (int i=1; i<=atom.natom; i++) { free(atom.evecz[i]); } free(atom.evecz);}
  if (atom.satom) {
    for (int i=1; i<=atom.natom; i++) {
      for (int j=0; j<3; j++) {	free(atom.satom[i][j]); }  free(atom.satom[i]); } 
    free(atom.satom); }
  if (atom.nneighbor) { delete[] atom.nneighbor; atom.nneighbor = NULL;
    for (int i=0; i<=atom.natom; i++) { delete[] atom.neighbor[i]; }
    delete[] atom.neighbor; atom.neighbor = NULL; }
  // Deallocate arrays end
  //printf("glDeletelists");
  //  if (glIsList(objects)) {glDeleteLists(objects, atom.natom*3+1); printf("glDeleteLists\n");}
  if (glIsList(objects+1)) {glDeleteLists(objects, atom.natom*3+1); printf("glDeleteLists\n"); }
  //  glDeleteLists(objects, atom.natom*3); printf("glDeleteLists %d %d\n",objects, atom.natom*3);


  // 1st line
  getline (finconfig, line);
  //  std::cout << count_arg_number(line) << std::endl;
  //  std::cout << "LINE1 = " << "\"" << line << "\"" << std::endl;
  get_first_arg(line, arg1); get_first_arg(line, arg2);
  //  std::cout << "ARG1 = " << "\"" << arg1 << "\"" << std::endl;
  //  std::cout << "ARG2 = " << "\"" << arg2 << "\"" << std::endl;
  //  strcpy(species, arg1.c_str()); printf("Species (1st line) = %s\n",species);
  strncpy(species, arg1.c_str(),sizeof(species)); species[2]='\0'; printf("Species (1st line) = %s\n",species);

  // 2nd line
  getline (finconfig, line);
  //  std::cout << "LINE2 = " << "\"" << line << "\"" << std::endl;
  get_first_arg(line, arg1); get_first_arg(line, arg2);
  //  std::cout << "ARG1 = " << "\"" << arg1 << "\"" << std::endl;
  //  std::cout << "ARG2 = " << "\"" << arg2 << "\"" << std::endl;
  //  strcpy(atom.potential_func, arg1.c_str());
  strncpy(atom.potential_func, arg1.c_str(),sizeof(atom.potential_func));
  printf("Potential (2nd line) = %s ",atom.potential_func);
  //  strcpy(atom.potential_arg,  arg2.c_str());
  strncpy(atom.potential_arg,  arg2.c_str(),sizeof(atom.potential_arg));
  printf("Potential arg (2nd line) = %s\n",atom.potential_arg);
  book.algo = 1;
  if (strcmp(atom.potential_func,"Tersoff")==0) { book.algo = 2; }
  if (strcmp(atom.potential_func,"Brenner")==0) { book.algo = 3; }

  ipottype=-99;
  for (int i=0; i<MAXPOTTYPE; i++) {
    //printf("%s %s\n",atom.potential_func, potstring_list[i]);
    std::string line = std::string(potstring_list[i]);
    std::string arg1, arg2; int narg = count_arg_number(line);
    if (narg==1) { get_first_arg(line,arg1);
    } else if (narg>=2) { get_first_arg(line,arg1); get_first_arg(line,arg2); }
    //if (strcmp(atom.potential_func, potstring_list[i]) == 0) { ipottype=i; }
    if (strcmp(atom.potential_func, arg1.c_str()) == 0) {
      if (narg==1) { ipottype=i;
      } else {
	if (strcmp(atom.potential_arg, arg2.c_str()) == 0) { ipottype=i; } }
    }
  }
  if (ipottype<0) {
    printf("################################################\n");
    printf("### WARNING: No match in available potential ###\n");
    printf("In CONFIG: %s\n",atom.potential_func);
    printf("Available potentials are:\n");
    for (int i=0; i<MAXPOTTYPE; i++) {
      printf("%d %s\n",i,potstring_list[i]);
    }
    printf("Potential is set to Morse\n");
    printf("################################################\n");
    strcpy(atom.potential_func,"Morse");ipottype=0;
  }


  // number of atoms, lattice constant and cell matrix
  finconfig >> atom.natom; //atom.nrepatom=atom.natom;
  //  std::cout << atom.natom << std::endl;
  atom.natom = atom.natom + natoms;

  // Allocate arrays
  //  color = (GLfloat **)malloc(sizeof(GLfloat*)*(atom.natom*3+1));
  //  for (int i=1; i<=atom.natom*3; i++) { color[i] = (GLfloat *)malloc(sizeof(GLfloat)*4); }
  color = (GLfloat **)malloc(sizeof(GLfloat*)*(atom.natom*3+1));
  color0 = (GLfloat **)malloc(sizeof(GLfloat*)*(atom.natom*3+1));
  for (int i=1; i<=atom.natom*3; i++) { color[i] = (GLfloat *)malloc(sizeof(GLfloat)*4); }
  for (int i=1; i<=atom.natom*3; i++) { color0[i] = (GLfloat *)malloc(sizeof(GLfloat)*4); }
  iatom  = (int *)calloc(atom.natom*2+1, sizeof(int));
  repidx = (int *)calloc(atom.natom*2+1, sizeof(int));
  atom.asp = (char **)malloc(sizeof(char*)*(atom.natom+1));
  for (int i=1; i<=atom.natom; i++) { atom.asp[i] = (char *)malloc(sizeof(char)*3); }
  atom.wm = new double[atom.natom+1];
  atom.rx = (double *)calloc(atom.natom+1, sizeof(double));
  atom.ry = (double *)calloc(atom.natom+1, sizeof(double));
  atom.rz = (double *)calloc(atom.natom+1, sizeof(double));
  atom.rx_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.ry_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.rz_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.rx_org = (double *)calloc(atom.natom+1, sizeof(double));
  atom.ry_org = (double *)calloc(atom.natom+1, sizeof(double));
  atom.rz_org = (double *)calloc(atom.natom+1, sizeof(double));
  atom.rx_p = (double *)calloc(atom.natom+1, sizeof(double));
  atom.ry_p = (double *)calloc(atom.natom+1, sizeof(double));
  atom.rz_p = (double *)calloc(atom.natom+1, sizeof(double));
  atom.vx = (double *)calloc(atom.natom+1, sizeof(double));
  atom.vy = (double *)calloc(atom.natom+1, sizeof(double));
  atom.vz = (double *)calloc(atom.natom+1, sizeof(double));
  atom.fx = (double *)calloc(atom.natom+1, sizeof(double));
  atom.fy = (double *)calloc(atom.natom+1, sizeof(double));
  atom.fz = (double *)calloc(atom.natom+1, sizeof(double));
  atom.fx_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.fy_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.fz_float = (FLOAT *)calloc(atom.natom+1, sizeof(FLOAT));
  atom.mfx = (bool *)calloc(atom.natom+1, sizeof(bool));
  atom.mfy = (bool *)calloc(atom.natom+1, sizeof(bool));
  atom.mfz = (bool *)calloc(atom.natom+1, sizeof(bool));
  atom.epot = (double *)calloc(atom.natom+1, sizeof(double));
  atom.epot_float = (FLOAT2 *)calloc(atom.natom+1, sizeof(FLOAT2));
  atom.repatom = (int *)calloc(atom.natom+1, sizeof(int));
  atom.elem_id = (int *)calloc(atom.natom+1, sizeof(int));
  atom.evecx = (double **)malloc(sizeof(double*)*(atom.natom+1));
  for (int i=1; i<=atom.natom; i++) { atom.evecx[i] = (double *)malloc(sizeof(double)*20); }
  atom.evecy = (double **)malloc(sizeof(double*)*(atom.natom+1));
  for (int i=1; i<=atom.natom; i++) { atom.evecy[i] = (double *)malloc(sizeof(double)*20); }
  atom.evecz = (double **)malloc(sizeof(double*)*(atom.natom+1));
  for (int i=1; i<=atom.natom; i++) { atom.evecz[i] = (double *)malloc(sizeof(double)*20); }
  atom.satom = (double ***)malloc(sizeof(double**)*(atom.natom+1));
  for (int i=1; i<=atom.natom; i++) {
    atom.satom[i] = (double **)malloc(sizeof(double*)*3);
    for (int j=0; j<3; j++) { atom.satom[i][j] = (double *)malloc(sizeof(double)*3); } }
  atom.nneighbor = new int[atom.natom+1]; atom.neighbor = new int*[atom.natom+1];
  for (int i=0; i<=atom.natom; i++) { atom.neighbor[i] = new int[MAXNEIGHBOR]; }
  
  // Allocate arrays end

  objects = glGenLists(atom.natom*3); printf("objects = %d\n",objects);
  //for (int i=1; i<=atom.natom*3; i++) { memcpy(color[i],yellow,sizeof(GLfloat)*4); }

  for (int i=1; i<=atom.natom; i++) { strcpy (atom.asp[i], species); }

  //  std::cout << atom.asp[1] << std::endl;

  finconfig >> cell.alat;
  finconfig >> cell.hmat[1][1];   finconfig >> cell.hmat[2][1];   finconfig >> cell.hmat[3][1]; 
  finconfig >> cell.hmat[1][2];   finconfig >> cell.hmat[2][2];   finconfig >> cell.hmat[3][2]; 
  finconfig >> cell.hmat[1][3];   finconfig >> cell.hmat[2][3];   finconfig >> cell.hmat[3][3]; 
  for (int i=1; i<=3; i++) {
    for (int j=1; j<=3; j++) {
      cell.hmat[i][j] = cell.hmat[i][j] * cell.alat * 1.0e-10;
      if (imerge==1) {
	float xab = cell.hmat[i][j]-hmats[i][j]; if (xab<0) { xab=-xab; }
	if (xab>1.0e-10) {
	  printf("##WARNING## hmat[%d][%d] is much different: ",i,j);
	  printf("%8.2f => %8.2f ang\n",hmats[i][j]*1.0e10, cell.hmat[i][j]*1.0e10);
	} } 
    }
  }
  cellx=cell.hmat[1][1]/ang;celly=cell.hmat[2][2]/ang;cellz=cell.hmat[3][3]/ang;
  // fra or abs line
  getline (finconfig, line);
  getline (finconfig, line);
  //  std::cout << "LINE = " << "\"" << line << "\"" << std::endl;
  get_first_arg(line, arg1); get_first_arg(line, arg2);
  if ((arg1 == "abs")||(arg1 == "ABS")) { abs = true; }
  //  std::cout << "ARG1 = " << "\"" << arg1 << "\"" << std::endl;
  //  std::cout << abs << std::endl;
  //  std::cout << "ARG2 = " << "\"" << arg2 << "\"" << std::endl;

  // atom coordinates
  if (atom.natom > NMAX) {
    std::cout << "NMAX is too small" << std::endl;
  }

  /*
  if (abs) {
    for (int i=1; i<=atom.natom; i++) {
      //      finconfig >> xx;  finconfig >> yy;   finconfig >> zz;
      if (i<=atom.natom-natoms) {
	getline(finconfig, line);
	get_first_arg(line, arg1); get_first_arg(line, arg2); get_first_arg(line, arg3);
	strcpy (larg1, arg1.c_str()); strcpy (larg2, arg2.c_str()); strcpy (larg3, arg3.c_str()); 
	xx = atof(larg1); yy = atof(larg2); zz = atof(larg3);
	atom.rx[i] = xx*1.0e-10; atom.ry[i] = yy*1.0e-10; atom.rz[i] = zz*1.0e-10;
      } else {
	atom.rx[i] = rxs[i-atom.natom+natoms]/hmats[1][1]*cell.hmat[1][1];
	atom.ry[i] = rys[i-atom.natom+natoms]/hmats[2][2]*cell.hmat[2][2];
	atom.rz[i] = rzs[i-atom.natom+natoms]/hmats[3][3]*cell.hmat[3][3];
      }
      atom.rx_org[i] = atom.rx[i]; atom.ry_org[i] = atom.ry[i]; atom.rz_org[i] = atom.rz[i]; 
      atom.vx[i] = 0.0; atom.vy[i] = 0.0; atom.vz[i] = 0.0;
    }
  } else {
  */
  for (int i=1; i<=atom.natom; i++) {
    if (i<=atom.natom-natoms) {
      getline(finconfig, line);
      if (count_arg_number(line)==3) {
	if (strcmp(species,"Mu") == 0) { printf("Error in CONFIG. Specify atom type.\n"); return; }
	get_first_arg(line, arg1); get_first_arg(line, arg2); get_first_arg(line, arg3);
	strcpy (larg1, arg1.c_str()); strcpy (larg2, arg2.c_str()); strcpy (larg3, arg3.c_str()); 
	xx = atof(larg1); yy = atof(larg2); zz = atof(larg3);
	atom.mfx[i] = false; atom.mfy[i] = false; atom.mfz[i] = false; 
      } else if (count_arg_number(line)==4) {
	get_first_arg(line, arg1); get_first_arg(line, arg2); get_first_arg(line, arg3); get_first_arg(line, arg4);
	strcpy (larg1, arg1.c_str()); strcpy (larg2, arg2.c_str()); strcpy (larg3, arg3.c_str());
	strcpy (atom.asp[i], arg4.c_str());
	xx = atof(larg1); yy = atof(larg2); zz = atof(larg3);
	atom.mfx[i] = false; atom.mfy[i] = false; atom.mfz[i] = false; 
      } else if (count_arg_number(line)==6) {
	if (strcmp(species,"Mu") == 0) { printf("Error in CONFIG. Specify atom type.\n"); return; }
	get_first_arg(line, arg1); get_first_arg(line, arg2); get_first_arg(line, arg3); get_first_arg(line, arg4);
	get_first_arg(line, arg5); get_first_arg(line, arg6);
	strcpy (larg1, arg1.c_str()); strcpy (larg2, arg2.c_str()); strcpy (larg3, arg3.c_str()); 
	strcpy (larg4, arg4.c_str()); strcpy (larg5, arg5.c_str()); strcpy (larg6, arg6.c_str());
	xx = atof(larg1); yy = atof(larg2); zz = atof(larg3);
	atom.mfx[i] = false; atom.mfy[i] = false; atom.mfz[i] = false; 
	if (strcmp(larg4,"F") == 0) { atom.mfx[i] = true; }
	if (strcmp(larg5,"F") == 0) { atom.mfy[i] = true; }
	if (strcmp(larg6,"F") == 0) { atom.mfz[i] = true; }
      } else if (count_arg_number(line)==7) {
	get_first_arg(line, arg1); get_first_arg(line, arg2); get_first_arg(line, arg3); get_first_arg(line, arg4);
	get_first_arg(line, arg5); get_first_arg(line, arg6); get_first_arg(line, arg7);
	strcpy (larg1, arg1.c_str()); strcpy (larg2, arg2.c_str()); strcpy (larg3, arg3.c_str()); 
	strcpy (larg5, arg5.c_str()); strcpy (larg6, arg6.c_str()); strcpy (larg7, arg7.c_str()); 
	strcpy (atom.asp[i], arg4.c_str());
	xx = atof(larg1); yy = atof(larg2); zz = atof(larg3);
	atom.mfx[i] = false; atom.mfy[i] = false; atom.mfz[i] = false; 
	if (strcmp(larg5,"F") == 0) { atom.mfx[i] = true; }
	if (strcmp(larg6,"F") == 0) { atom.mfy[i] = true; }
	if (strcmp(larg7,"F") == 0) { atom.mfz[i] = true; }
      } else {
	std::cout << "Error in reading config: Line has "<<count_arg_number(line)<<" args"<<std::endl;
      }
      if (abs) {
	atom.rx[i] = xx*1.0e-10; atom.ry[i] = yy*1.0e-10; atom.rz[i] = zz*1.0e-10;
      } else {
	atom.rx[i] = cell.hmat[1][1]*xx + cell.hmat[1][2]*yy + cell.hmat[1][3]*zz;
	atom.ry[i] = cell.hmat[2][1]*xx + cell.hmat[2][2]*yy + cell.hmat[2][3]*zz;
	atom.rz[i] = cell.hmat[3][1]*xx + cell.hmat[3][2]*yy + cell.hmat[3][3]*zz;
      }
    } else {
      atom.rx[i] = rxs[i-atom.natom+natoms]/hmats[1][1]*cell.hmat[1][1];
      atom.ry[i] = rys[i-atom.natom+natoms]/hmats[2][2]*cell.hmat[2][2];
      atom.rz[i] = rzs[i-atom.natom+natoms]/hmats[3][3]*cell.hmat[3][3];
      atom.mfx[i] = false; atom.mfy[i] = false; atom.mfz[i] = false; 
    }	
    atom.rx_org[i] = atom.rx[i]; atom.ry_org[i] = atom.ry[i]; atom.rz_org[i] = atom.rz[i]; 
    atom.vx[i] = 0.0; atom.vy[i] = 0.0; atom.vz[i] = 0.0;
  }
  // Atom weight
  //atom.wm = 1.6726e-27*63.55;
  set_atom_color();
  set_atom_weight();
  for (int i=1; i<=3; i++) {
    for (int j=1; j<=3; j++) {
      cell.hmat_org[i][j]=cell.hmat[i][j];
    }
  }
  istep = 0;
  ex = 0.0;
  out_of_cell();
  pot_initialize_all();
  bookkeep();
  potential();
  // For output in "Status" area
  f_max=atom.Fmax()/ev*ang;
  epotatom=atom.epotsum/ev/atom.natom;
}

void get_first_arg(std::string &line, std::string &arg1)
{
  int istt = line.find_first_not_of(" ");
  if (istt == -1) {
    arg1 = "";
  } else {
    line = line.substr(istt);
    int iend = line.find_first_of(" ");
    if (iend == -1) { iend = line.length(); }
    //  std::cout<<istt<< " " <<iend<<std::endl;
    arg1 = line.substr(0,iend);
    //  std::cout<<line <<" " <<arg1 <<std::endl;
    line = line.substr(iend);
  }
}
void get_first_arg(char* line, char* arg1)
{
  if (strchr(line,' ')==NULL) { strcpy(arg1,line);
  } else {
    int l=strchr(line,' ')-line; int len=strlen(line);
    strncpy(arg1,line,l);
    for (int i=l+1; i<=len; i++) {
      if (line[i]==' ') { l++; }
    }
    for (int i=l+1; i<=len; i++) {
      line[i-l-1]=line[i];
    }
  }
    
}

int remove_head_spaces(std::string &line)
{
  int istt = line.find_first_not_of(" ");
  if (istt == -1) {
    return -1;
  } else {
    line=line.substr(istt);
    return 0;
  }
}

int sprit_first_arg(std::string &line, std::string &arg1)
{
    int iend = line.find_first_of(" ");
    //    std::cout<<iend<<std::endl;
    if (iend == -1) { // no space, only one arg
      arg1 = line;
      line = "";
      return -1;
    } else  {
     arg1 = line.substr(0,iend);
     line = line.substr(iend);
     if (remove_head_spaces(line) == -1) {
       line = "";
       return -1;
     }
     return 0;
    }
}
  
int count_arg_number(std::string line)
{
  std::string cline, arg;
  cline = line;
  int count = 0;
  if (remove_head_spaces(cline) == -1) {
    return 0;
  } 
  for (int i=1; i<=100; i++) {
    if (sprit_first_arg(cline, arg) == -1) {
      count++;
      return count;
    } else {
      count++;
    }
  }
  std::cout << "Error: a line has more than 100 args" << std::endl;
  return 999;
}

void set_atom_weight()
{
  double am = 1.6726485e-27;
  for (int i=1; i<=atom.natom; i++) {
    if (strcmp(atom.potential_func,"Shellmodel")==0) {
      if ((strcmp(atom.asp[i],"Pb")==0)||(strcmp(atom.asp[i],"pb")==0)) {
	if (i<=atom.natom/2) { atom.wm[i]=am*207.2; // Core
	} else { atom.wm[i]=am*207.2; } // Shell
      } else if ((strcmp(atom.asp[i],"Ti")==0)||(strcmp(atom.asp[i],"ti")==0)) {
	if (i<=atom.natom/2) { atom.wm[i]=am*47.9; // Core
	} else { atom.wm[i]=am*47.9; } // Shell
      } else if ((strcmp(atom.asp[i],"O")==0)||(strcmp(atom.asp[i],"o")==0)) {
	if (i<=atom.natom/2) { atom.wm[i]=am*15.9994; // Core
	} else { atom.wm[i]=am*15.9994; } // Shell
      }
    } else {
      if ((strcmp(atom.asp[i],"C")==0)||(strcmp(atom.asp[i],"c")==0)) {
	atom.wm[i]=am*12.01;
      } else if ((strcmp(atom.asp[i],"Pb")==0)||(strcmp(atom.asp[i],"pb")==0)) {
	atom.wm[i]=am*207.2;
      } else if ((strcmp(atom.asp[i],"Mo")==0)||(strcmp(atom.asp[i],"mo")==0)) {
	atom.wm[i]=am*95.94;
      } else if ((strcmp(atom.asp[i],"Ta")==0)||(strcmp(atom.asp[i],"ta")==0)) {
	atom.wm[i]=am*180.95;
      } else if ((strcmp(atom.asp[i],"Mg")==0)||(strcmp(atom.asp[i],"mg")==0)) {
	atom.wm[i]=am*24.305;
      } else if ((strcmp(atom.asp[i],"Co")==0)||(strcmp(atom.asp[i],"co")==0)) {
	atom.wm[i]=am*58.93;
      } else if ((strcmp(atom.asp[i],"Ti")==0)||(strcmp(atom.asp[i],"ti")==0)) {
	atom.wm[i]=am*47.9;
      } else if ((strcmp(atom.asp[i],"Zr")==0)||(strcmp(atom.asp[i],"zr")==0)) {
	atom.wm[i]=am*91.22;
      } else if ((strcmp(atom.asp[i],"Cu")==0)||(strcmp(atom.asp[i],"cu")==0)) {
	atom.wm[i]=am*63.55;
      } else if ((strcmp(atom.asp[i],"Al")==0)||(strcmp(atom.asp[i],"al")==0)) {
	atom.wm[i]=am*26.982;
      } else if ((strcmp(atom.asp[i],"Si")==0)||(strcmp(atom.asp[i],"si")==0)) {
	atom.wm[i]=am*28.086;
      } else if ((strcmp(atom.asp[i],"Ge")==0)||(strcmp(atom.asp[i],"ge")==0)) {
	atom.wm[i]=am*72.59;
      } else if ((strcmp(atom.asp[i],"Cr")==0)||(strcmp(atom.asp[i],"cr")==0)) {
	atom.wm[i]=am*52.00;
      } else if ((strcmp(atom.asp[i],"Fe")==0)||(strcmp(atom.asp[i],"fe")==0)) {
	atom.wm[i]=am*55.85;
      } else if ((strcmp(atom.asp[i],"Ni")==0)||(strcmp(atom.asp[i],"ni")==0)) {
	atom.wm[i]=am*58.71;
      } else if ((strcmp(atom.asp[i],"Ag")==0)||(strcmp(atom.asp[i],"ag")==0)) {
	atom.wm[i]=am*107.87;
      } else if ((strcmp(atom.asp[i],"Au")==0)||(strcmp(atom.asp[i],"au")==0)) {
	atom.wm[i]=am*196.97;
      } else if ((strcmp(atom.asp[i],"Pd")==0)||(strcmp(atom.asp[i],"pd")==0)) {
	atom.wm[i]=am*106.40;
      } else if ((strcmp(atom.asp[i],"Sn")==0)||(strcmp(atom.asp[i],"sn")==0)) {
	atom.wm[i]=am*118.69;
      } else if ((strcmp(atom.asp[i],"W")==0)||(strcmp(atom.asp[i],"w")==0)) {
	atom.wm[i]=am*183.85;
      } else if ((strcmp(atom.asp[i],"Pt")==0)||(strcmp(atom.asp[i],"pt")==0)) {
	atom.wm[i]=am*195.09;
      } else if ((strcmp(atom.asp[i],"H")==0)||(strcmp(atom.asp[i],"h")==0)) {
	atom.wm[i]=am*1.0079;
      } else if ((strcmp(atom.asp[i],"O")==0)||(strcmp(atom.asp[i],"o")==0)) {
	atom.wm[i]=am*16;
      } else if ((strcmp(atom.asp[i],"Y")==0)||(strcmp(atom.asp[i],"y")==0)) {
	atom.wm[i]=am*78;
      } else {
	printf("WARNING: Weight data not found for i= %d, %s\n",i,atom.asp[i]); atom.wm[i] = am*10.0; } 
    }
  }
    /*
      wmave=0.0d0
      do i=1,n
      wmave=wmave+atom.wm[i]
      enddo
      wmave=wmave/dble(n)
    */
}
