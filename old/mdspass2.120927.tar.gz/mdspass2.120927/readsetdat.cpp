#include <string>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

#define NONEINT -99999
#define NONEDOUBLE -1.0e30

extern int radius, show_cnt_wall, show_cnt_wallv, show_cnt_wall_num;
extern int show_axis, show_cell, relax_algo;
extern int draw_bond, draw_force;
extern int mode_cnt_corrugation;
extern float bondlength, dtm, vscl_force;
extern int mdspeed;
extern int cnt_load_algo;

void get_first_arg(std::string &line, std::string &arg1);

double find_double(char* fname, char* tag)
{
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  double arg = NONEDOUBLE;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      arg = (double)atof(arg2.c_str());
    }
  }
  fin.close();
  return arg;
}

int find_int(char* fname, char* tag)
{
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  int arg = NONEINT;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      arg = atoi(arg2.c_str());
    }
  }
  fin.close();
  return arg;
}

int find_bool(char* fname, char* tag)
{
  std::ifstream fin(fname);
  std::string line, arg1, arg2;
  int arg = -1;
  for (int i=1; i<=100; i++) {
    getline (fin, line);
    get_first_arg(line, arg1); get_first_arg(line, arg2);
    if (strcmp(arg1.c_str(), tag)==0) {
      if (strcmp(arg2.c_str(), "Yes")==0) {
	arg = 1;
      } else if (strcmp(arg2.c_str(), "yes")==0) {
	arg = 1;
      } else if (strcmp(arg2.c_str(), "YES")==0) {
	arg = 1;
      } else if (strcmp(arg2.c_str(), "No")==0) {
	arg = 0;
      } else if (strcmp(arg2.c_str(), "no")==0) {
	arg = 0;
      } else if (strcmp(arg2.c_str(), "NO")==0) {
	arg = 0;
      }
    }
  }
  fin.close();
  return arg;
}

void get_dat(char* fname, char* tag, double &val)
{
  if (find_double(fname, tag)!=NONEDOUBLE) {
    val = find_double(fname, tag); printf("# %s = %e (double)\n", tag, val); } 
}
void get_dat(char* fname, char* tag, float &val)
{
  if (find_double(fname, tag)!=NONEDOUBLE) {
    val = (float)find_double(fname, tag); printf("# %s = %e (float)\n", tag, val); } 
}
void get_dat(char* fname, char* tag, bool &val)
{
  if (find_bool(fname, tag) > -1 ) {
    val = find_bool(fname, tag);
    if (val == true) { printf("# %s = yes\n", tag); }
    else { printf("# %s = no\n", tag); } } 
}
void get_dat(char* fname, char* tag, int &val)
{
  if (find_bool(fname, tag) > -1) {
    val = find_bool(fname, tag);
    if (val == true) { printf("# %s = yes\n", tag); }
    else { printf("# %s = no\n", tag); }
  } else if (find_int(fname, tag)!=NONEINT) {
    val = find_int(fname, tag); printf("# %s = %d\n", tag, val);
  }
}

void readsetdat(char* fname)
{
  printf("### Read %s ###\n",fname);
  get_dat(fname, "dt", dt);
  get_dat(fname, "frc", book.frc); book.frc2 = book.frc*book.frc;
  get_dat(fname, "nbk", book.nbk);
  get_dat(fname, "pbcx", cell.pbcx);
  get_dat(fname, "pbcy", cell.pbcy);
  get_dat(fname, "pbcz", cell.pbcz);
  get_dat(fname, "radius", radius);
  get_dat(fname, "draw_bond", draw_bond);
  get_dat(fname, "draw_force", draw_force);
  get_dat(fname, "forcelength", vscl_force);
  get_dat(fname, "bondlength", bondlength);
  //draw_bond = find_bool(fname, "draw_bond");
  //draw_force = find_bool(fname, "draw_force");
  //vscl_force = (float)find_double(fname, "forcelength");
  //bondlength = (float)find_double(fname, "bondlength");
  get_dat(fname, "show_cell", show_cell);
  get_dat(fname, "show_axis", show_axis);
  get_dat(fname, "no_trans", notrans);
  get_dat(fname, "temp", temp_set);
  get_dat(fname, "show_cnt_wall", show_cnt_wall);
  get_dat(fname, "show_cnt_wallv", show_cnt_wallv);
  get_dat(fname, "show_cnt_wall_num", show_cnt_wall_num);
  get_dat(fname, "cnt_corrugation", mode_cnt_corrugation);
  get_dat(fname, "ffdtmax", fire.ffdtmax);
  get_dat(fname, "mdmotion", mdmotion);
  get_dat(fname, "ensemble", ensemble);
  /*
  show_cell = find_bool(fname, "show_cell");
  show_axis = find_bool(fname, "show_axis");
  notrans = find_bool(fname, "no_trans");
  temp_set = find_double(fname, "temp");
  show_cnt_wall = find_bool(fname, "show_cnt_wall");
  show_cnt_wallv = find_bool(fname, "show_cnt_wallv");
  show_cnt_wall_num = find_int(fname, "show_cnt_wall_num");
  mode_cnt_corrugation = find_bool(fname, "cnt_corrugation");
  fire.ffdtmax = find_double(fname, "ffdtmax");
  mdmotion = find_bool(fname, "mdmotion");
  ensemble = find_int(fname, "ensemble");
  */
  get_dat(fname, "dexdt", dexdt);
  get_dat(fname, "deydt", deydt);
  get_dat(fname, "dezdt", dezdt);
  get_dat(fname, "repeat_lz", repeat_lz);
  get_dat(fname, "repeat_lz_min", repeat_lz_min);
  get_dat(fname, "repeat_lz_max", repeat_lz_min);
  get_dat(fname, "relax_algo", relax_algo);
  get_dat(fname, "redraw_interval", mdspeed);
  get_dat(fname, "cnt_load_algo", cnt_load_algo);
  /*
  repeat_lz = find_bool(fname, "repeat_lz");
  repeat_lz_min = (float)find_double(fname, "repeat_lz_min");
  repeat_lz_max = (float)find_double(fname, "repeat_lz_max");
  relax_algo = find_int(fname, "relax_algo");
  */
  printf("### Read %s end ###\n",fname);

  dtm = (float)dt*1e15;

  /*
  char string[80];
  FILE *fp = fopen("setdat","r");
  fgets(string, 80, fp);
  printf("%s\n",string);
  */
}
