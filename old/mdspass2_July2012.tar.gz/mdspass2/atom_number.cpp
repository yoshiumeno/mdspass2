#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

int atom_number(char* at)
{
  int type;
  if (strcmp(at,"Cu")==0) { type = 29; }
  return type;
}
