#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

void cnt_wall_setnormalvectors(); void cnt_wall_centering();
extern bool mode_cnt_corrugation;
extern float cnt_pressure, cnt_pressure_ftot;

void loading()
{
 if (mode_cnt_corrugation) {
   double factor = 1.0e-10*cnt_pressure;
   cnt_wall_setnormalvectors();
   cnt_pressure_ftot = 0.0;
   for (int i=1; i<=atom.nwall; i++) {
     int i0 = atom.wall_v[i][0]; int i1 = atom.wall_v[i][1]; int i2 = atom.wall_v[i][2];
     double fxx = atom.wall_nvec[i][0]*factor;
     double fyy = atom.wall_nvec[i][1]*factor;
     double fzz = atom.wall_nvec[i][2]*factor;
     cnt_pressure_ftot = cnt_pressure_ftot + fxx*fxx+fyy*fyy+fzz*fzz;
     atom.fx[i0] = atom.fx[i0] + fxx; atom.fy[i0] = atom.fy[i0] + fyy; atom.fz[i0] = atom.fz[i0] + fzz;
     atom.fx[i1] = atom.fx[i1] + fxx; atom.fy[i1] = atom.fy[i1] + fyy; atom.fz[i1] = atom.fz[i1] + fzz;
     atom.fx[i2] = atom.fx[i2] + fxx; atom.fy[i2] = atom.fy[i2] + fyy; atom.fz[i2] = atom.fz[i2] + fzz;
   }
   cnt_pressure_ftot = sqrt(cnt_pressure_ftot)/(double)atom.natom*1e9; // force per atom (in nN)
   //printf("CNT pressure: Force per atom = %f (nN)\n",cnt_pressure_ftot);
 }
}
