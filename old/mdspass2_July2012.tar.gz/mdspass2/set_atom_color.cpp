#include <string>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"
#include <GL/glui.h>

extern GLfloat **color;

void set_atom_color()
{
  GLfloat red[] = {1.0, 0.0, 0.0, 1.0};
  GLfloat yellow[] = {1.0, 1.0, 0.0, 1.0};
  GLfloat white[] = {0.8, 0.8, 0.8, 1.0};
  GLfloat gray[] = { 0.7, 0.7, 0.7 };
  GLfloat blue[] = { 0.1, 0.1, 0.9 };
  GLfloat green[] = { 0.0, 1.0, 0.0 };
  for (int i=1; i<=atom.natom*3; i++) { memcpy(color[i],yellow,sizeof(GLfloat)*4); }
}
