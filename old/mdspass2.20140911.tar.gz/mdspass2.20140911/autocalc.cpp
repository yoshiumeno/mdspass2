#include <string.h>
#include <string>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

void bookkeep();
void potential();
void loading();
void calculate();
void stretch_celladjust_d(double c1x, double c1y, double c1z,
			  double c2x, double c2y, double c2z,
			  double c3x, double c3y, double c3z);

extern float auto_val1, auto_val2;

void autocalc()
{
  printf("Auto calculation\n");
  printf("(please consult autocalc.cpp to see what is being done)\n");
  double c1x, c1y, c1z, c2x, c2y, c2z, c3x, c3y, c3z;
  c1x = cell.hmat[0][0]/ang;
  c1y = cell.hmat[1][0]/ang;
  c1z = cell.hmat[2][0]/ang;
  c2x = cell.hmat[0][1]/ang;
  c2y = cell.hmat[1][1]/ang;
  c2z = cell.hmat[2][1]/ang;
  //c3x = cell.hmat[0][2]/ang;
  c3x = (double)auto_val1;
  c3y = cell.hmat[1][2]/ang;
  c3z = cell.hmat[2][2]/ang;

  double ytarget = -2000;
  double tol = 10.0;
  double xmin = (double)auto_val2 - 0.005;
  double xmax = (double)auto_val2 + 0.005;
  double xcnt;
  double ymin, ymax, ycnt;
  double ep;
  stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmin); 
  calculate(); ymin = cell.sgmmat[2][2]/MPa;
  stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmax);
  calculate(); ymax = cell.sgmmat[2][2]/MPa;
  printf("Initial: x = %f - %f, y = %f - %f\n",xmin,xmax,ymin,ymax);
START:
  for (int ite=0; ite<20; ite++) {
    xcnt = (xmin+xmax)/2.0;
    stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmin);
    calculate(); ymin = cell.sgmmat[2][2]/MPa;
    if (abs(ymin-ytarget) < tol) { break; }
    if (ymin > ytarget) {
      double xx = xmax-xmin;
      xmin -= xx; xmax -= xx; ite--; continue; }
    stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmax);
    calculate(); ymax = cell.sgmmat[2][2]/MPa;
    if (abs(ymax-ytarget) < tol) { break; }
    if (ymax < ytarget) {
      double xx = xmax-xmin;
      xmax += xx; xmin += xx; ite--; continue; }
    stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xcnt);
    calculate(); ycnt = cell.sgmmat[2][2]/MPa;
    if (ycnt > ytarget) { xmin = xcnt; }
    if (ycnt < ytarget) { xmax = xcnt; }
  }
  printf("\n");
  stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmin);
  calculate(); ymin = cell.sgmmat[2][2]/MPa; double zx1 = cell.sgmmat[2][0]/MPa;
  ep = atom.epotsum/ev/(double)atom.natom;
  printf("%12.8f %12.8f %20.10e %12.8f %12.8f\n",c3x,xmin,ep,ymin,zx1);
  stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,xmax);
  calculate(); ymax = cell.sgmmat[2][2]/MPa; double zx2 = cell.sgmmat[2][0]/MPa;
  ep = atom.epotsum/ev/(double)atom.natom;
  printf("%12.8f %12.8f %20.10e %12.8f %12.8f\n",c3x,xmax,ep,ymax,zx2);

  

  //for (double x=(double)auto_val2-0.0001; x<(double)auto_val2+0.0001; x += 0.00001) {
  //  c3z = x;
  //  stretch_celladjust_d(c1x,c1y,c1z,c2x,c2y,c2z,c3x,c3y,c3z);
  //  calculate();
  //  printf("%f %f %f %f\n",c3z,c3x,cell.sgmmat[2][2]/MPa,cell.sgmmat[2][0]/MPa);
  //}
}

void calculate() {
    bookkeep(); potential(); loading();
    // For output in "Status" area
    //cellx=cell.hmat[0][0]/ang;celly=cell.hmat[1][1]/ang;cellz=cell.hmat[2][2]/ang;
    cellx=sqrt(cell.hmat[0][0]*cell.hmat[0][0]+cell.hmat[1][0]*cell.hmat[1][0]+cell.hmat[2][0]*cell.hmat[2][0])/ang;
    celly=sqrt(cell.hmat[0][1]*cell.hmat[0][1]+cell.hmat[1][1]*cell.hmat[1][1]+cell.hmat[2][1]*cell.hmat[2][1])/ang;
    cellz=sqrt(cell.hmat[0][2]*cell.hmat[0][2]+cell.hmat[1][2]*cell.hmat[1][2]+cell.hmat[2][2]*cell.hmat[2][2])/ang;
    cell1x=cell.hmat[0][0]/ang;cell1y=cell.hmat[1][0]/ang;cell1z=cell.hmat[2][0]/ang;
    cell2x=cell.hmat[0][1]/ang;cell2y=cell.hmat[1][1]/ang;cell2z=cell.hmat[2][1]/ang;
    cell3x=cell.hmat[0][2]/ang;cell3y=cell.hmat[1][2]/ang;cell3z=cell.hmat[2][2]/ang;
    f_max=atom.Fmax()/ev*ang;
    epotatom=atom.epotsum/ev/atom.natom;

}
