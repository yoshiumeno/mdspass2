#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"
#if defined __linux__ || defined __APPLE__
#include <unistd.h>
#else
#include <direct.h>
#endif

void e_force_morse();
void e_force_geam_am();
void e_force_brenner();
void e_force_brenner(int mode);
void e_force_tersoff();
void e_force_mishin(PotentialMode mode);
void e_force_dipole(PotentialMode mode);
void e_force_combined();
void e_force_adp();
void calcstresstensor();
void bookkeep();
void get_first_arg(std::string &line, std::string &arg1);
int count_arg_number(std::string line);
void set_potfile();
void set_potfile(const char* fname);
void pot_initialize_all();

extern std::string potfile;
extern char cwdname[80];

void potential_set (int control)
{
  printf("Potential: No. %d, %s\n",ipottype,potstring_list[ipottype]);
  //strcpy(atom.potential_func, potstring_list[ipottype]);
  std::string line = std::string(potstring_list[ipottype]);
  std::string arg1, arg2; int narg = count_arg_number(line);
  if (narg==1) { get_first_arg(line,arg1);
    strcpy(atom.potential_func, arg1.c_str());
    strcpy(atom.potential_arg, "");
  } else { get_first_arg(line,arg1); get_first_arg(line,arg2);
    strcpy(atom.potential_func, arg1.c_str());
    strcpy(atom.potential_arg,  arg2.c_str()); }
  book.algo = 1;
  //if (strcmp(atom.potential_func,"Tersoff")==0) { book.algo = 2; }
  if (strcmp(atom.potential_func,"Brenner")==0) { book.algo = 3; }
  if (strcmp(atom.potential_func,"AIREBO" )==0) { book.algo = 3; }
  pot_initialize_all();
}

void potential()
{
 CALC:
  if (strcmp(atom.potential_func, "Morse") == 0) {
    e_force_morse();
  } else if (strcmp(atom.potential_func, "GEAM") == 0) {
    e_force_geam_am();
  } else if (strcmp(atom.potential_func, "Brenner") == 0) {
    e_force_brenner();
  } else if (strcmp(atom.potential_func, "AIREBO") == 0) {
    e_force_brenner(1);
  } else if (strcmp(atom.potential_func, "Tersoff") == 0) {
    e_force_tersoff();
  } else if ((strcmp(atom.potential_func, "EAM") == 0)&&
	     (strcmp(atom.potential_arg, "Mishin") == 0)) {
    e_force_mishin(NORMALPOTMODE);
  } else if (strcmp(atom.potential_func, "Dipole") == 0) {
    e_force_dipole(NORMALPOTMODE);
  } else if (strcmp(atom.potential_func, "ADP") == 0) {
    e_force_adp();
  } else if (strcmp(atom.potential_func, "NiYSZ") == 0) {
    e_force_combined();
  } else {
    printf("##### Invalid potential for this system #####\n");
    mdmotion = 0;
    return;
  }

  // Set rcut_f
  if (log10(rcut)<-8) { rcut_f = rcut*1e10; } // Some routines use rcut in [m]
  else { rcut_f = rcut; }

  // Is frc enough?
  //printf("%f %f\n",rcut_f, book.frc/ang);
  if (!tersoff.nocutoff) {
  if (rcut_f > book.frc / ang) {
    book.frc = ((double)rcut_f + frcmar) * ang;
    frc_f = book.frc / ang;
    bookkeep();
    goto CALC;
  }
  }
  // For output in "Stresss" area
  calcstresstensor();
  strs_xx = cell.sgmmat[0][0]*1e-6;
  strs_yy = cell.sgmmat[1][1]*1e-6;
  strs_zz = cell.sgmmat[2][2]*1e-6;
  strs_xy = cell.sgmmat[0][1]*1e-6;
  strs_yz = cell.sgmmat[1][2]*1e-6;
  strs_zx = cell.sgmmat[2][0]*1e-6;
}

void set_potfile()
{
  if (strcmp(atom.potential_func, "Dipole") == 0) {
    printf("Dipole parameter file is set to %s\n",potfile.c_str());
    strcpy(dipole.fname,potfile.c_str());
    dipole.initialize = true;
  } else if (strcmp(atom.potential_func, "ADP") == 0) {
    printf("ADP parameter file is set to %s\n",potfile.c_str());
    strcpy(adp.fname,potfile.c_str());
    adp.initialize = true;
  } else if (strcmp(atom.potential_func, "Pair") == 0) {
    printf("Pair parameter file is set to %s\n",potfile.c_str());
    if (pairPot == NULL) pairPot = new Buckingham(4, 1, COMBINEDPOTMODE);
    strcpy(pairPot->fname,potfile.c_str());
    pairPot->initialized = false;
  }

}
void set_potfile(const char* fname)
{
  char fname0[80] = "aaa";
  getcwd(cwdname,80);
  strcpy(fname0,cwdname);
#if defined __linux__ || defined __APPLE__
  strcat(fname0,"/pot/");
#else
  strcat(fname0,"\\pot\\");
#endif
  strcat(fname0,fname);
  if (strcmp(atom.potential_func, "Dipole") == 0) {
    printf("Dipole parameter file is set to %s\n",fname);
    strcpy(dipole.fname,fname0);
    dipole.initialize = true;
  } else if (strcmp(atom.potential_func, "ADP") == 0) {
    printf("ADP parameter file is set to %s\n",fname);
    strcpy(adp.fname,fname0);
    adp.initialize = true;
  } else if (strcmp(atom.potential_func, "Pair") == 0) {
    printf("Pair parameter file is set to %s\n",fname);
    if (pairPot == NULL) pairPot = new Buckingham(4, 1, COMBINEDPOTMODE);
    strcpy(pairPot->fname,fname0);
    pairPot->initialized = false;
  }
}

void pot_initialize_all()
{
  bre.initialize = true;
  tersoff.initialize = true;
  eammis.initialize = true;
  geam.initialize = true;
  adp.initialize = true;
  dipole.initialize = true;
  if (pairPot == NULL) pairPot = new Buckingham(4, 1, COMBINEDPOTMODE);
}
