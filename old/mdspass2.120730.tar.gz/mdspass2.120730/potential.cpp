#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "myheader.h"

void e_force_morse();
void e_force_geam_am();
void e_force_brenner();
void e_force_tersoff();
void e_force_mishin();

void potential()
{
  if (strcmp(atom.potential_func, "Morse") == 0) {
    e_force_morse();
  } else if (strcmp(atom.potential_func, "GEAM") == 0) {
    e_force_geam_am();
  } else if (strcmp(atom.potential_func, "Brenner") == 0) {
    e_force_brenner();
  } else if (strcmp(atom.potential_func, "Tersoff") == 0) {
    e_force_tersoff();
  } else if (strcmp(atom.potential_func, "EAM") == 0) {
    e_force_mishin();
  } else {
    printf("##### Invalid potential for this system #####\n");
    mdmotion = 0;
    return;
  }
}
