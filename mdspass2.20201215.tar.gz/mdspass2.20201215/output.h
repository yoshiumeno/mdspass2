#include <iostream>
#include <string>
#include <cstdio>

/* class for output on screen */
class Output
{
	public:
		static void ShowError(const char*);
		static void ShowWarning(const char*);
		static void ShowMessage(const char*);
};
