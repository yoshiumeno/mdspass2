#include <fstream>
#include <iostream>
#include "myheader.h"

extern float rotate[15], obj_pos[3], scl;

void view_save()
{
  FILE *fp = fopen("VIEW","w");
  fprintf(fp, "%f %f %f %f\n",rotate[ 0],rotate[ 1],rotate[ 2],rotate[ 3]);
  fprintf(fp, "%f %f %f %f\n",rotate[ 4],rotate[ 5],rotate[ 6],rotate[ 7]);
  fprintf(fp, "%f %f %f %f\n",rotate[ 8],rotate[ 9],rotate[10],rotate[11]);
  fprintf(fp, "%f %f %f %f\n",rotate[12],rotate[13],rotate[14],rotate[15]);
  fprintf(fp, "%f %f %f\n", obj_pos[0], obj_pos[1], obj_pos[2]);
  fprintf(fp, "%f\n",scl);
  fclose(fp);
  printf("View data is saved to VIEW\n");
}

void view_read()
{
  FILE *fp;
  if (fp = fopen("VIEW","r")) {
    fscanf(fp, "%f %f %f %f\n",&rotate[ 0],&rotate[ 1],&rotate[ 2],&rotate[ 3]);
    fscanf(fp, "%f %f %f %f\n",&rotate[ 4],&rotate[ 5],&rotate[ 6],&rotate[ 7]);
    fscanf(fp, "%f %f %f %f\n",&rotate[ 8],&rotate[ 9],&rotate[10],&rotate[11]);
    fscanf(fp, "%f %f %f %f\n",&rotate[12],&rotate[13],&rotate[14],&rotate[15]);
    fscanf(fp, "%f %f %f\n", &obj_pos[0], &obj_pos[1], &obj_pos[2]);
    fscanf(fp, "%f\n",&scl);
    fclose(fp);
    printf("View data is read from VIEW\n");
  }
}
