#include <fstream>
#include <iostream>
#include "myheader.h"

extern float rotatemat[15], obj_pos[3], scl;

void view_save()
{
  FILE *fp = fopen("VIEW","w");
  fprintf(fp, "%f %f %f %f\n",rotatemat[ 0],rotatemat[ 1],rotatemat[ 2],rotatemat[ 3]);
  fprintf(fp, "%f %f %f %f\n",rotatemat[ 4],rotatemat[ 5],rotatemat[ 6],rotatemat[ 7]);
  fprintf(fp, "%f %f %f %f\n",rotatemat[ 8],rotatemat[ 9],rotatemat[10],rotatemat[11]);
  fprintf(fp, "%f %f %f %f\n",rotatemat[12],rotatemat[13],rotatemat[14],rotatemat[15]);
  fprintf(fp, "%f %f %f\n", obj_pos[0], obj_pos[1], obj_pos[2]);
  fprintf(fp, "%f\n",scl);
  fclose(fp);
  printf("View data is saved to VIEW\n");
}

void view_read()
{
  FILE *fp;
  if (fp = fopen("VIEW","r")) {
    fscanf(fp, "%f %f %f %f\n",&rotatemat[ 0],&rotatemat[ 1],&rotatemat[ 2],&rotatemat[ 3]);
    fscanf(fp, "%f %f %f %f\n",&rotatemat[ 4],&rotatemat[ 5],&rotatemat[ 6],&rotatemat[ 7]);
    fscanf(fp, "%f %f %f %f\n",&rotatemat[ 8],&rotatemat[ 9],&rotatemat[10],&rotatemat[11]);
    fscanf(fp, "%f %f %f %f\n",&rotatemat[12],&rotatemat[13],&rotatemat[14],&rotatemat[15]);
    fscanf(fp, "%f %f %f\n", &obj_pos[0], &obj_pos[1], &obj_pos[2]);
    fscanf(fp, "%f\n",&scl);
    fclose(fp);
    printf("View data is read from VIEW\n");
  }
}
