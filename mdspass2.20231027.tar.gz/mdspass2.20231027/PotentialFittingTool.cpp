
#include <iostream>
#include <vector>
#include <iomanip>
#include "Configuration.h"
#include "Input.h"
#include "ReaxFF.h"
#include "ReaxPotential.h"
#include "Population.h"
#include "Utils.h"
#include "DifferentialEvolution.h"
#include "PowellMinimization.h"
#include "PFMPI.h"

using namespace std;

int main(int argc, char* argv[])
{
  PFMPI::Init(&argc, &argv);

  if( argc != 2 ) {
    if( PFMPI::s_master ) {
      cerr << "Usage: " << argv[0] << " inputfile " << endl;
    }
    PFMPI::Finalize();
    return 1;
  }

  Input input;
  if( !input.ReadFile(argv[1]) ) {
    PFMPI::Finalize();
    return 2;
  }

  Utils::SetRandomSeed(input.m_nRandomSeed);

  ConfigurationSet confSet;
  if( !confSet.ReadFile(input.m_strConfigFile) ) {
    PFMPI::Finalize();
    return 3;
  }

  ConfigurationSet confSetRef;
  if( !confSetRef.ReadFile(input.m_strReferenceFile) ) {
    PFMPI::Finalize();
    return 4;
  }

  Potential pot;
  if( !pot.ReadFile(input.m_strInitialPotentialFile) ) {
    PFMPI::Finalize();
    return 5;
  }
  
  if( !ReaxFF::Initialize(pot, confSet, confSetRef, input) ) {
    PFMPI::Finalize();
    return 6;
  }

  DifferentialEvolution::Run(pot, input);

  PowellMinimization::Run(pot, input);

  if( !pot.WriteFile(input.m_strOutputPotentialFile) ) {
    PFMPI::Finalize();
    return 7;
  }

  PFMPI::Finalize();
  return 0;
}
