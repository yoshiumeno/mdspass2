#include <fstream>
#include <iostream>

int main()
{
 int ix = 20;
 int iy = 30;
 FILE *fp = fopen("PATTERN","w");
 fprintf(fp, "%d %d\n",ix,iy);
 for (int j=0; j<iy; j++) {
   for (int i=0; i<ix; i++) {
     fprintf(fp, "%d ",0);
   } fprintf(fp, "\n");
 }
 fclose(fp);
}
